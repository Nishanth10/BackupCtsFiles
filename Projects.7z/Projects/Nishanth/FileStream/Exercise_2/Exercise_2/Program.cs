﻿using System;
using System.IO;
using System.Xml;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_2
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream fs = new FileStream(@"D:/XmlLOB.xml",

        FileMode.OpenOrCreate, FileAccess.Write);

            //Create XmlWriter and tag it with fs

            XmlWriter writter = XmlWriter.Create(fs);

            //Start the xml document writing

            writter.WriteStartDocument();

            //Write start node (main node)

            writter.WriteStartElement("CTSLOB");



            //create sub node called employee

            writter.WriteStartElement("LOB");

            writter.WriteAttributeString("isActive", "true");

            writter.WriteElementString("Name", "BFS");


            //close sub node employee

            writter.WriteEndElement();



            //create sub node called employee

            writter.WriteStartElement("LOB");

            writter.WriteAttributeString("isActive", "true");

            writter.WriteElementString("Name", "Healthcare");


            //close sub node employee

            writter.WriteEndElement();

            //create sub node called employee

            writter.WriteStartElement("LOB");

            writter.WriteAttributeString("isActive", "true");

            writter.WriteElementString("Name", "Insurance");


            //close sub node employee

            writter.WriteEndElement();



            //Close the main node

            writter.WriteEndElement();

            //Stop the xml document writing

            writter.WriteEndDocument();

            writter.Close();

            fs.Close();

          //  Console.WriteLine("XML document creation completed");

            //Read data from xml in console environment

            FileStream fs1 = new FileStream(@"D:/XmlLOB.xml",

              FileMode.OpenOrCreate, FileAccess.Read);

            //Create XmlReader

            XmlReader reader = XmlReader.Create(fs1);

            //read() data from xml file

            while (reader.Read())

            {
                switch (reader.NodeType)

                {

                    
                    case XmlNodeType.Text: //ie data under element

                        Console.WriteLine(reader.Value);
                        break;

                }
            }

            



            reader.Close();

            fs1.Close();

            //Console.WriteLine("Reading completed");
        }
    }
}
