﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example
{
    class Project
    {
        private int _projId;
        private string _projName;

        public Project()
        {

        }

        public Project(int _projId, string _projName)
        {
            this.ProjId = _projId;
            this.ProjName = _projName;
        }

        public int ProjId
        {
            get
            {
                return _projId;
            }

            set
            {
                _projId = value;
            }
        }

        public string ProjName
        {
            get
            {
                return _projName;
            }

            set
            {
                _projName = value;
            }
        }
    }
}
