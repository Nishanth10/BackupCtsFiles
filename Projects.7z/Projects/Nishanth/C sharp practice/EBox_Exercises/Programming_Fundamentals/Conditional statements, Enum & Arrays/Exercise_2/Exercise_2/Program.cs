﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_2
{
    class Time_Keeping
    {
        static void Main(string[] args)
        {
            string time = Console.ReadLine();
            if(time.Equals("Morning"))
            {
                Console.WriteLine("Friends");
            }
            else if (time.Equals("Afternoon"))
            {
                Console.WriteLine("Girlfriend");
            }
            else if (time.Equals("Evening"))
            {
                Console.WriteLine("Practice");
            }
            else if (time.Equals("Night"))
            {
                Console.WriteLine("Biking");
            }
        }
    }
}