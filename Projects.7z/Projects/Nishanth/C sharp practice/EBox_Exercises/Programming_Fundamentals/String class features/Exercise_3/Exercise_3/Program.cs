﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter venue1 ");
            string venue1 = Console.ReadLine();
            Console.WriteLine("Enter venue2 ");
            string venue2 = Console.ReadLine();
            if(venue1.Equals(venue2,StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Both the venues are same.");
            }
            else
            {
                Console.WriteLine("Both the venues are different.");
            }
        }
    }
}
