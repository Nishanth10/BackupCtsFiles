﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter team name");
            string team = Console.ReadLine();
            Console.WriteLine("Enter starting index of the sequence");
            int start = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter ending index of the sequence");
            int end = int.Parse(Console.ReadLine());
            string extract = team.Substring(start, end);
            Console.WriteLine(extract);
        }
    }
}
