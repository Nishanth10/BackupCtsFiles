﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Player name");
            string player = Console.ReadLine();
            Console.WriteLine("Enter starting index");
            int pos = int.Parse(Console.ReadLine());
            string extract = player.Substring(pos);
            Console.WriteLine("Short name of "+player+": "+extract);
        }
    }
}
