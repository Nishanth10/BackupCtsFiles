﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Exercise_2
    {
        static void arithmeticProgression(ref int n)
        {
            int diff = 2;
            int ap = 1;
            while(ap<n)
            {
                Console.WriteLine(ap);
                ap = ap + diff;
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Please provide the limit until which the Arithmetic progression series has to be printed");
            int num = int.Parse(Console.ReadLine());
            int flag = 1;
            if (num>=21)
            {
                Console.WriteLine("Please provide the maximum value less than 20");
                while(flag!=0)
                {
                    num = int.Parse(Console.ReadLine());
                    if(num>=21)
                    {
                        Console.WriteLine("Please provide the maximum value less than 20");
                        flag = 1;
                    }
                    else
                    {
                        flag = 0;
                        arithmeticProgression(ref num);

                    }
                }
            }
            else
            {
                arithmeticProgression(ref num);
            }
        }
    }
}
