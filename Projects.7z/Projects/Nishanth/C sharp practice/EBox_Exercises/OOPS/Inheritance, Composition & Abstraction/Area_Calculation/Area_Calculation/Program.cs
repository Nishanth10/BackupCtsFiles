﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Area_Calculation
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Circle\nSquare\nRectangle");
            Console.WriteLine("Enter the shape name");
            string name = Console.ReadLine();
            if(name.Equals("Circle",StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Enter the radius");
                int radius = int.Parse(Console.ReadLine());

                Circle circle = new Circle(radius, name);
                float carea = circle.CalculateArea();
                Console.WriteLine("Area of Circle is " + carea.ToString("0.00"));
            }

            else if (name.Equals("Square", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Enter the side");
                int side = int.Parse(Console.ReadLine());

                Square square = new Square(side, name);
                float sarea = square.CalculateArea();
                Console.WriteLine("Area of Square is "+ sarea.ToString("0.00"));

            }

            else if (name.Equals("Rectangle", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Enter the length");
                int length = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the breadth");
                int breadth = int.Parse(Console.ReadLine());

                Rectangle rectangle = new Rectangle(length, breadth, name);
                float rarea = rectangle.CalculateArea();
                Console.WriteLine("Area of Rectangle is " + rarea.ToString("0.00"));
            }
        }
    }
}
