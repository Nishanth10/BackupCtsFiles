﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkillsData
{
    class Skill
    {
        private string _name;
        private int _experienceInYears;

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public int ExperienceInYears
        {
            get
            {
                return _experienceInYears;
            }

            set
            {
                _experienceInYears = value;
            }
        }

        public Skill(string _name, int _experienceInYears)
        {
            this.Name = _name;
            this.ExperienceInYears = _experienceInYears;
        }

        public override string ToString()
        {
            return string.Format("{0} with {1} years of experience", this._name, this._experienceInYears);
        }
    }
}
