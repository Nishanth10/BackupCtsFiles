﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkillsData
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Please enter the player name: ");
            string name = Console.ReadLine();
            Console.WriteLine("Please enter the skill name: ");
            string sName = Console.ReadLine();
            Console.WriteLine("Please enter the experience in years: ");
            int experienceInYears = int.Parse(Console.ReadLine());

            Skill skl = new Skill(sName, experienceInYears);
            Player ply = new Player(name, skl);


            //Call the BO for output

            Console.WriteLine("Hi BCCI. Here is the player skill details: ");

            Utility.DisplayPlayerSkillDetail(ply);
        }
    }
}
