﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkillsData
{
    class Player
    {
        private String _name;
        private Skill _skill;

        public Player(string _name, Skill _skill)
        {
            this.Name = _name;
            this.Skill = _skill;
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        internal Skill Skill
        {
            get
            {
                return _skill;
            }

            set
            {
                _skill = value;
            }
        }

        public override string ToString() 
        {
            return string.Format("{0},{1}",  this._name, this._skill);
        }
    }
}
