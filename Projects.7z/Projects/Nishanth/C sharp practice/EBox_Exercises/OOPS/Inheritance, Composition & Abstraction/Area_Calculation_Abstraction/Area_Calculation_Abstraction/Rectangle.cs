﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Area_Calculation
{
    class Rectangle : Shape
    {
        private int _length;
        private int _breadth;

        public Rectangle(int _length, int _breadth, string _name) :
            base(_name)
        {
            this.Length = _length;
            this.Breadth = _breadth;
        }

        public int Length
        {
            get
            {
                return _length;
            }

            set
            {
                _length = value;
            }
        }

        public int Breadth
        {
            get
            {
                return _breadth;
            }

            set
            {
                _breadth = value;
            }
        }

        public override float CalculateArea()
        {
            return this._length * this._breadth;
        }
    }
}