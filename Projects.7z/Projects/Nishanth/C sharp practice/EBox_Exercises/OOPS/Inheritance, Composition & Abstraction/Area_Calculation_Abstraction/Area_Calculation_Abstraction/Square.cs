﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Area_Calculation
{
    class Square : Shape
    {
        private int _side;

        public Square(int _side, string _name) :
            base(_name)
        {
            this.Side = _side;
        }

        public int Side
        {
            get
            {
                return _side;
            }

            set
            {
                _side = value;
            }
        }

        public override float CalculateArea()
        {
            return this._side * this._side;
        }
    }
}
