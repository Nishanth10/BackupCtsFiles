﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Area_Calculation
{
    class Circle : Shape
    {
        private int _radius;

        public Circle(int _radius, string _name) :
            base(_name)
        {
            this.Radius = _radius;
        }

        public int Radius
        {
            get
            {
                return _radius;
            }

            set
            {
                _radius = value;
            }
        }

        public override float CalculateArea()
        {
            return 3.14F * this._radius * this._radius;
        }
    }
}
