﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delivery_Details
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter the over");
            long _over = long.Parse(Console.ReadLine());

            Console.WriteLine("Enter the ball");
            long _ball = long.Parse(Console.ReadLine());

            Console.WriteLine("Enter the runs");
            long _runs = long.Parse(Console.ReadLine());

            Console.WriteLine("Enter the batsman");
            string _batsman = Console.ReadLine();

            Console.WriteLine("Enter the bowler");
            string _bowler = Console.ReadLine();

            Console.WriteLine("Enter the nonStriker");
            string _nonStriker = Console.ReadLine();

            Delivery del = new Delivery(_over, _ball, _runs, _batsman, _bowler, _nonStriker);
            Console.WriteLine(del);
        }
    
    }
}
