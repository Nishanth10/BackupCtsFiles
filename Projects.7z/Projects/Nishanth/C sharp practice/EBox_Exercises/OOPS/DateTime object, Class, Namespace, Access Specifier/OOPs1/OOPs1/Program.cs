﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPs1
{
    class Program
    {
        static void Main(string[] args)
        {

            Player dao = new Player();

            Console.WriteLine("Enter the player name ");
            string _name = Console.ReadLine();

            Console.WriteLine("Enter the country name ");
            string _country = Console.ReadLine();

            Console.WriteLine("Enter the skill ");
            string _skill = Console.ReadLine();

            //setter()

            dao.Name = _name;
            dao.Country = _country;
            dao.Skill = _skill;



            //getter()

            Console.WriteLine();
            Console.WriteLine("Player Details : ");

            Console.WriteLine("Player Name : " + dao.Name);
            Console.WriteLine("Country Name : " + dao.Country);
            Console.WriteLine("Skill : " + dao.Skill);
        }
    }
}
