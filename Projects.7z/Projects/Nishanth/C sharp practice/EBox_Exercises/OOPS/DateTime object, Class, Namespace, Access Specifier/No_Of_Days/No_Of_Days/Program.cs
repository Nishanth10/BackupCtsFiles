﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace No_Of_Days
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your date of joining in ‘mm/dd/yyyy’ format in your current organization. ");
            DateTime data = DateTime.ParseExact(Console.ReadLine(), "MM/dd/yyyy", null);
            DateTime current = DateTime.Now;
            TimeSpan ts = current.Subtract(data);
            int duration = (int)ts.TotalDays-1;
            Console.WriteLine("It has been " + duration + " days since you joined the current organization.");
        }
    }
}
