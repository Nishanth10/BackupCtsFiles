﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Menu\n1.Cricket Player Details \n2.Hockey Player Details ");
            int detailsnumber = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the player name");
            string playerName = Console.ReadLine();
            Console.WriteLine("Enter the Team name");
            string teamName = Console.ReadLine();
            if (detailsnumber == 1)
            {
                Console.WriteLine("Enter the number of matches played");
                int numberOfMatches = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter total runs scored");
                int runsScored = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter total number of wickets taken ");
                int noOfWickets = int.Parse(Console.ReadLine());
                CricketPlayer cricketPlayer = new CricketPlayer(runsScored, noOfWickets, playerName, teamName, numberOfMatches);
                cricketPlayer.DisplayPlayerStatistics();
            }
            else
            {
                Console.WriteLine("Enter the number of matches played");
                int numberOfMatches = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the position");
                string position = Console.ReadLine();
                Console.WriteLine("Enter total number of goals taken");
                int noOfGoals = int.Parse(Console.ReadLine());
                HockeyPlayer hockeyPlayer = new HockeyPlayer(position, noOfGoals, playerName, teamName, numberOfMatches);
                hockeyPlayer.DisplayPlayerStatistics();

            }
        }
    }

}
