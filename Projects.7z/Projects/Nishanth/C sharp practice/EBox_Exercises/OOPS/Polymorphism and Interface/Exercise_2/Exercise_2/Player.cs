﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Exercise_2
{
    class Player
    {
        private string _name;
        private int _noOfMatches;
        private string _teamName;

        public Player()
        {

        }
        public Player(string _name, string _teamName, int _noOfMatches)
        {
            this.Name = _name;
            this.TeamName = _teamName;
            this.NoOfMatches = _noOfMatches;
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public int NoOfMatches
        {
            get
            {
                return _noOfMatches;
            }

            set
            {
                _noOfMatches = value;
            }
        }

        public string TeamName
        {
            get
            {
                return _teamName;
            }

            set
            {
                _teamName = value;
            }
        }
    }
}