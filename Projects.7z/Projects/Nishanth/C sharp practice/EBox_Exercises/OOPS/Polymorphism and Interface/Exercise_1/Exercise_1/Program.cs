﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Menu\n1.Player details of the delivery\n2.Run details of the delivery");
            int detailsnumber = int.Parse(Console.ReadLine());
            Delivery delivery = new Delivery();
            if (detailsnumber == 1)
            {
                Console.WriteLine("Enter the bowler name");
                string bowlername = Console.ReadLine();
                Console.WriteLine("Enter the batsman name");
                string batsmanname = Console.ReadLine();
                delivery.DisplayDeliveryDetails(bowlername, batsmanname);
            }
            else
            {
                Console.WriteLine("Enter the number of runs");
                int runs = int.Parse(Console.ReadLine());
                delivery.DisplayDeliveryDetails(runs);
            }

        }
    }
}
