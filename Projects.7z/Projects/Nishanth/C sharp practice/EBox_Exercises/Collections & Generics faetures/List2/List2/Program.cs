﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace List2
{
    class Program
    {
        static void Main(string[] args)
        {

            List<int> runs = new List<int>();

            int run_in;

            int no = int.Parse(Console.ReadLine());

            for (int i = 0; i < no; i++)
            {
                run_in = int.Parse(Console.ReadLine());
                runs.Add(run_in);
            }


            runs.Sort();
            Console.WriteLine();

            foreach (var run in runs)
            {
                Console.WriteLine(run);
            }

        }
    }
}
