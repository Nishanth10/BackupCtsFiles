﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace List
{
    class Program
    {
        static void Main(string[] args)
        {

            List<string> brands = new List<string>();

            brands.Add("Videocon");
            brands.Add("Onida");
            brands.Add("Samsung");



            Console.WriteLine("List of currently available " + brands.Count + " Television brands");

            foreach (string brand in brands)

            {

                Console.WriteLine(brand);

            }

            Console.WriteLine("Please enter the Television brand to add to the list ");
            string brand_add = Console.ReadLine();

            brands.Add(brand_add);

            Console.WriteLine("\nList of currently available " + brands.Count  + " Television brands ");

            foreach (string brand in brands)

            {

                Console.WriteLine(brand);

            }


        }
    }
}
