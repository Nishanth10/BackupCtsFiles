﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Interface
{
    class UI
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter batch code and location seperated by comma");
            string[] batchInfo = Console.ReadLine().Split(',');
            Console.WriteLine("Enter trainee name,marks1 and marks2 using comma");
            string[] traineeInfo = Console.ReadLine().Split(',');

            Trainee tr = new Trainee(batchInfo[0], batchInfo[1],
              traineeInfo[0], float.Parse(traineeInfo[1]),
              float.Parse(traineeInfo[2]));

            Console.WriteLine("\nDisplay Trainee information:");
            CTraineeBO.Display(tr);
            Console.WriteLine("Marks: " +
              tr.Result(float.Parse(traineeInfo[1]), 
              float.Parse(traineeInfo[2])));

            Console.WriteLine("Enter the hours this week");
            int TraineeDutyHours = tr.attendanceTracker(
                int.Parse(Console.ReadLine()));

            if(TraineeDutyHours < 400)
            {
                Console.WriteLine("Top up required= " +
                    (400 - TraineeDutyHours));
            }
            else
            {
                Console.WriteLine("Total hours completed: " +
                    TraineeDutyHours);
            }

            Console.WriteLine("Enter Passport NO (NA if not present):");
            string passport = Console.ReadLine();
            bool check = tr.hrPolicy(passport);
            if (check)
            {
                Console.WriteLine("Passport submitted");
            }
            else
            {
                Console.WriteLine("Passport submission pending with HR");
            }

        }
    }
}
