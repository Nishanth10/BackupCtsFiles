﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Anonymous_Type
{
    class Program
    {
        static void Main(string[] args)
        {
            //Design Time

            var name = "Sam";

            var id = 1001;

            var fees = 100.23F;

            var salary = 90000.23;



            //To get Datatype info at runtime use a method: GetType()

            Console.WriteLine("Name= " + name + " Type: " + name.GetType());

            Console.WriteLine("Id= " + id + " Type: " + id.GetType());

            Console.WriteLine("Fees= " + fees + " Type: " + fees.GetType());

            Console.WriteLine("Salary= " + salary

              + " Type: " + salary.GetType());
        }
    }
}
