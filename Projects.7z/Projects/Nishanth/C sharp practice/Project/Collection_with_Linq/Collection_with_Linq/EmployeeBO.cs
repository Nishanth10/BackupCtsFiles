﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collection_with_Linq
{
    class EmployeeBO:Exception
    {
        public static void Display(List<Employee> empList)

        {

            foreach (Employee emp in empList)

            {

                Console.WriteLine(emp);

            }

        }

        public static Employee Display(List<Employee> empList, int searchId)

        {

            Employee emp = null;

            var check_data = from d in empList

                             where d.Id == searchId

                             select d;

            if (check_data.Count() > 0) //data is found

            {

                foreach (Employee emp1 in check_data)

                {

                    emp = emp1;

                    break;

                }

            }

            return emp;

        }
        /* public static Employee Display(List<Employee> empList,int searchId)
         {

         }*/
        //Exception handler

        private string _message;
        public EmployeeBO()
        {

        }
        public EmployeeBO(string _message)
        {
            this._message = _message;
        }
        public string Message1
        {
            get
            {
                return _message;
            }

            set
            {
                _message = value;
            }

        }
        public override string ToString()
        {
            return string.Format("{0}", this._message);
        }
    }
}
