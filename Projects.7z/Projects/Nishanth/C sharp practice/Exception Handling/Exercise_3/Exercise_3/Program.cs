﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_3
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {

                Console.WriteLine("Please enter the first number ");
                string _in1 = Console.ReadLine();
                if (_in1 == null || _in1 == "")
                {
                    throw new Custom("Please provide valid input ");
                }

                Console.WriteLine("Please enter the second number ");
                string _in2 = Console.ReadLine();
                if (_in2 == null || _in2 == "")
                {
                    throw new Custom("Please provide valid input ");
                }

                int _num1 = int.Parse(_in1);
                int _num2 = int.Parse(_in2);
                Console.WriteLine(Custom.GetNumber(_num1, _num2));

            }

            catch (FormatException ex)
            {
                Console.WriteLine(ex);
            }

            catch (Custom e)
            {
                Console.WriteLine(e);
            }


        }

    }
}

