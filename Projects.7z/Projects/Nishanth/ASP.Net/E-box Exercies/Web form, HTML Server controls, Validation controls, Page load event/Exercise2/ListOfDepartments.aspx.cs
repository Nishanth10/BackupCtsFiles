﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            List<string> departmentsList = new List<string>();
            departmentsList.Add("Select....");
            departmentsList.Add("Mechanical");
            departmentsList.Add("EEE");
            departmentsList.Add("Computer Science");
            departmentsList.Add("Information Technology");
            departmentsList.Add("ECE");


            ddlDepartments.DataSource = departmentsList;
          
            ddlDepartments.DataBind();
          
        }
    }


    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        displayLabel.Text = "Your Selected Department: " +
           ddlDepartments.SelectedItem.Text;
    }
}