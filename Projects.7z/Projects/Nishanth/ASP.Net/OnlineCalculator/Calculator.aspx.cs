﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//Add a namespace to access data from web.config file
using System.Configuration;

public partial class Calculator : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //call the data from appSettings via the key
        string batchInfo = ConfigurationManager.AppSettings["BatchName"].ToString();
        Response.Write("Site Manager: " + batchInfo);

    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            int number1 = int.Parse(txtNumber1.Text);
            int number2 = int.Parse(txtNumber2.Text);
            int result = 0;  // Addition(number1, number2);
            CalculatorServiceCall.CalculatorWebServiceSoapClient client =
                new CalculatorServiceCall.CalculatorWebServiceSoapClient();
            result = client.Addition(number1, number2);
            txtResult.Text = result.ToString();
        }
        catch(Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
        finally
        {
            //While your site is not complete give some errors in page
            //so that when the button is clicked it goes to site maintenance page
            //Response.Redirect("FormBug.aspx");
        }
    }

    protected void btnSubtract_Click(object sender, EventArgs e)
    {
        try
        {
            int number1 = int.Parse(txtNumber1.Text);
            int number2 = int.Parse(txtNumber2.Text);
            int result = 0;
            CalculatorServiceCall.CalculatorWebServiceSoapClient client =
                new CalculatorServiceCall.CalculatorWebServiceSoapClient();
            result = client.Subtract(number1, number2);
            txtResult.Text = result.ToString();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }
        finally
        {
            //While your site is not complete give some errors in page
            //so that when the button is clicked it goes to site maintenance page
            //Response.Redirect("FormBug.aspx");
        }
    }
}