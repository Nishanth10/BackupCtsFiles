﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//use namespace System.Data.SqlClient for sql data provider
using System.Data.SqlClient;
//Add namespace to tell command type
using System.Data;

namespace ADO.Net_App1
{
    class DepartmentDAO
    {
        //call the Helper property and store under a variable
        static string callconnection = Helper.ConnectionVariable;
        //All Query should be declared under global variables
        static string selectDepartment = "select * from department";

        public static void DisplayDepartment()
        {
            //create a SQL Connection object to connect with MS SQL Server 
            //If you use the using directive you do not have to call the 
            //close() method for connection [closed automatically]
            using (SqlConnection con = new SqlConnection(callconnection))
            {
                //open the connection
                con.Open();

                //write SQL Command to get data from department
                SqlCommand cmd = new SqlCommand();
                //Tell the connection for SQL
                cmd.Connection = con;
                //Tell what type of SQL command you are writting
                cmd.CommandType = System.Data.CommandType.Text;
                //Call the query text global variable
                cmd.CommandText = selectDepartment;

                List<DepartmentDL> deptList = new List<DepartmentDL>();
                //These 2 variables will hold database records
                int id = 0;
                string name = string.Empty;

                //create a DataReader and execute the cmd command
                //through the reader to read data line by line
                SqlDataReader dr = cmd.ExecuteReader();

                //Read data with a loop
                while(dr.Read())
                {
                    //store de_id under id variable
                    //dr.GetOrdinal will find the column by name
                    //dr.GetValue will extract the value from the column
                    id = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("de_id")));
                    name = Convert.ToString(dr.GetValue(dr.GetOrdinal("de_name")));
                    //pas the values under class constructor and add the
                    //class object to list
                    deptList.Add(new DepartmentDL(id, name));
                }

                //close the datareader after all data is read
                dr.Close();

                //extract data from List for display
                foreach(DepartmentDL dept in deptList)
                {
                    Console.WriteLine(dept);
                }
            }
        }
    }
}
