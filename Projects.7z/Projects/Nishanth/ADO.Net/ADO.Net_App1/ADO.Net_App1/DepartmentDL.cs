﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO.Net_App1
{
    class DepartmentDL
    {
        private int deptId;
        private string deptName;

        public DepartmentDL()
        {
                
        }

        public DepartmentDL(int deptId, string deptName)
        {
            this.DeptId = deptId;
            this.DeptName = deptName;
        }

        public int DeptId
        {
            get
            {
                return deptId;
            }

            set
            {
                deptId = value;
            }
        }

        public string DeptName
        {
            get
            {
                return deptName;
            }

            set
            {
                deptName = value;
            }
        }

        public override string ToString()
        {
            return string.Format("{0,-20}{1}", this.deptId, this.deptName);
        }
    }
}
