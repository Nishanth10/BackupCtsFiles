﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO.Net_App1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("{0,-20}{1}", "Department Id", "Department Name");
            try
            {
                DepartmentDAO.DisplayDepartment();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

    }
}
