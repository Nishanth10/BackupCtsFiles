﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQtoSQL_Example
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeDAO.DisplayAllEmployeeData();
            Console.WriteLine("\n\nTrainee Count: ");
            Console.WriteLine("Enter year: ");
            int year = int.Parse(Console.ReadLine());
            EmployeeDAO.DisplayCount(year);
        }
    }
}
