﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQtoSQL_Example
{
    class EmployeeDAO
    {
        /*Generate a DataContext Object for connectio */
        public static EmployeeDataClassDataContext con = 
            new EmployeeDataClassDataContext();
        public static void DisplayAllEmployeeData()
        {
            /*Extract data from the table called employee present 
             * under datacontext class through linq query */
            var query = from x in con.employees select x;

            foreach (employee emp in query)
            {
                Console.WriteLine(emp.em_id + "--" + emp.em_name + "--" + emp.em_email);
            }
        }

        public static void DisplayCount(int year)
        {
            var query = (from x in con.employees
                         where
                         x.emp_joining_year == year
                         select x).Count();

            Console.WriteLine(query);
        }
    }
}
