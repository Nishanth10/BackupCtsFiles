﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO_TransScope
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter employee name to search: ");
            string empName = Console.ReadLine();
            Console.WriteLine("Enter new id for department: ");
            int deptId = int.Parse(Console.ReadLine());
            EmployeeDAO.DisplayDepartment(deptId, empName);
        }
    }
}
