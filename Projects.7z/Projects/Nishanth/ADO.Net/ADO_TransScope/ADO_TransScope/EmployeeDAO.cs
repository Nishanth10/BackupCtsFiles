﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//use namespace System.Data.SqlClient for sql data provider
using System.Data.SqlClient;
//Add namespace to tell command type
using System.Data;
//Add the System.Transaction namespace
using System.Transactions;


namespace ADO_TransScope
{
    class EmployeeDAO
    {
        //call the Helper property and store under a variable
        public static string callconnection = Helper.ConnectionVariable;
        //All Query should be declared under the global variables
        static string updateEmployee = "update employee set de_em_id=@newid where em_name=@name";
        //take a Transaction class to tell backend server the status of transaction
        static SqlTransaction tr = null;

        public static void DisplayDepartment(int deptId, string emName)
        {
            //write the queries under try-catch block to handle exception

            try
            {
                //create a TransactionScope Class object to handle Transaction-Commit/Rollback
                using (TransactionScope scope = new TransactionScope())
                {
                    //Commit or rollback the Transaction
                    using (SqlConnection con = new SqlConnection(callconnection))
                    {
                        //Also if you want you can explicitly start the transaction

                        //open the connection
                        con.Open();
                        //Begin the transaction
                        tr = con.BeginTransaction();
                        //Write SQL Command to get data from department
                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = con;
                        //Tell what type of SQL command you are writing 
                        cmd.CommandType = CommandType.Text;
                        //Call the query text global variable
                        cmd.CommandText = updateEmployee;

                        //Map the query string parameters with method args
                        cmd.Parameters.Add("@newId", SqlDbType.Int).Value = deptId;
                        cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = emName;

                        //execute the update command and store update result in an integer variable
                        int result = cmd.ExecuteNonQuery();

                        //check if result > 0 ie update successfull
                        if (result > 0)
                        {
                            Console.WriteLine("Update successfull");
                            //Tell .Net compiler that the transaction is complete
                            scope.Complete();
                            //commit the transaction in backend 
                            tr.Commit();

                        }
                        else //update not successfull
                        {
                            tr.Rollback();
                            throw new TransactionAbortedException();
                        }
                    }
                }
            }
            catch (TransactionAbortedException ex)
            {

                Console.WriteLine("Error: " + ex.Message); ;
                Console.WriteLine("Department not present in Primary column");
                //Rollback the transaction
                tr.Rollback();
            }
        }
    }

}

