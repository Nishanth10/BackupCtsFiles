﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Add the namespace System.Configuration to call connection variable from app.config
using System.Configuration;
    public class Helper
    {
        static string variable = ConfigurationManager.ConnectionStrings["db_connection"].ToString();
            //ConfigurationManager.ConnectionStrings[] contain the connection variable
        public static string ConnectionVariable
        {
            get
            {
                return variable;
            }
        }
    }

