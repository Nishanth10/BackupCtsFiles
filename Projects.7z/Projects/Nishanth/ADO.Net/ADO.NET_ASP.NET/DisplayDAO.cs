﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//use namespace System.Data.SqlClient for sql data provider
using System.Data.SqlClient;
//Add namespace to tell command type
using System.Data;

namespace Business
{
    public class DisplayDAO
    {
        //call the Helper property and store under a variable
        static string callconnection = Helper.ConnectionVariable;
        //All Query should be declared under global variables
        static string displayJoin = "select em_name as Name,emp_joining_year as [Joining Year],de_name as Department from employee join department on employee.em_id=department.de_id";

        public static void DisplayDepartment()
        {
            //create a SQL Connection object to connect with MS SQL Server 
            //If you use the using directive you do not have to call the 
            //close() method for connection [closed automatically]
            using (SqlConnection con = new SqlConnection(callconnection))
            {
                //open the connection
                con.Open();

                //write SQL Command to get data from department
                SqlCommand cmd = new SqlCommand();
                //Tell the connection for SQL
                cmd.Connection = con;
                //Tell what type of SQL command you are writting
                cmd.CommandType = System.Data.CommandType.Text;
                //Call the query text global variable
                cmd.CommandText = displayJoin;

                //Take a DataAdapter to extract all data; ie, execute the command 
                //under the DataAdapter
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                //Take a Dataset to store data locally
                DataSet ds = new DataSet();
                da.Fill(ds);

                //Tell the GridView which is the datasource to collect data
                GridView1.DataSource = ds;
                //Bind the data to GridView
                GridView1.DataBind();

            }
        }
    }
}

