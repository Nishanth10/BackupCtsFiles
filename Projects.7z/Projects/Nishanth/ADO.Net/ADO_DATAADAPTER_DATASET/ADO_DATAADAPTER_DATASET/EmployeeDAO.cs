﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//use namespace System.Data.SqlClient for sql data provider
using System.Data.SqlClient;
//Add namespace to tell command type
using System.Data;

namespace ADO_DATAADAPTER_DATASET
{
    class EmployeeDAO
    {
        //call the Helper property and store under a variable
        static string callconnection = Helper.ConnectionVariable;
        //All Query should be declared under global variables
        static string selectDepartment = "select * from employee";

        public static void DisplayEmployees()
        {
            //create a SQL Connection object to connect with MS SQL Server 
            //If you use the using directive you do not have to call the 
            //close() method for connection [closed automatically]
            try
            {
                using (SqlConnection con = new SqlConnection(callconnection))
                {
                    //open the connection
                    con.Open();

                    //write SQL Command to get data from department
                    SqlCommand cmd = new SqlCommand();
                    //Tell the connection for SQL
                    cmd.Connection = con;
                    //Tell what type of SQL command you are writting
                    cmd.CommandType = System.Data.CommandType.Text;
                    //Call the query text global variable
                    cmd.CommandText = selectDepartment;

                    //Execute the command under DataAdapter is read bulk data at a time
                    SqlDataAdapter da = new SqlDataAdapter(cmd);

                    //Store the data in dataset
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    //close the connection with sql server once data is read
                    //in dataset [disconnected structure]
                    //con.Close(); This line is done automatically by the using directive

                    //Now extract data for display it will be from dataset
                    //use DataTableReader class to read the sql data table
                    //present under dataset
                    using (DataTableReader dr = ds.CreateDataReader())
                    {
                        while (dr.Read()) //Read data till last row
                        {
                            Console.WriteLine(
                                Convert.ToString(dr.GetValue(dr.GetOrdinal("em_name"))) + "---" +
                                Convert.ToString(dr.GetValue(dr.GetOrdinal("em_email"))) + "---" +
                                Convert.ToInt32(dr.GetValue(dr.GetOrdinal("emp_joining_year"))));
                        }

                    }

                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
    }
}
