﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//use namespace System.Data.SqlClient for sql data provider
using System.Data.SqlClient;
//Add namespace to tell command type
using System.Data;

namespace Count_ADO.NET
{
    class CountEmployeeDAO
    {
        //call the Helper property and store under a variable
        static string callconnection = Helper.ConnectionVariable;
        //All Query should be declared under global variables
        //static string countEmployee = "select * from employee where emp_joining_year=@year";
        static string countEmployee = "select count(emp_joining_year) from employee where emp_joining_year=@year";
        public static int DisplayCount(int yearOfJoining)
        {
            //create a SQL Connection object to connect with MS SQL Server 
            //If you use the using directive you do not have to call the 
            //close() method for connection [closed automatically]
                using (SqlConnection con = new SqlConnection(callconnection))
                {
                    //open the connection
                    con.Open();

                    //write SQL Command to get data from department
                    SqlCommand cmd = new SqlCommand();
                    //Tell the connection for SQL
                    cmd.Connection = con;
                    //Tell what type of SQL command you are writting
                    cmd.CommandType = System.Data.CommandType.Text;
                    //Call the query text global variable
                    cmd.CommandText = countEmployee;

                    //Map the SQL parameter with method argument
                    //cmd.Parameter.Add("@Parameter",SqlDbType.Datatype).Value=method_arg
                    cmd.Parameters.Add("@year", SqlDbType.Int).Value = yearOfJoining;

                    int result = (int)cmd.ExecuteScalar();
                    return result;
                /*
                    SqlDataReader dr = cmd.ExecuteReader();
                    List<int> countList = new List<int>();
                    int year = 0;
                    //Read data with a loop
                    while (dr.Read())
                    {
                        year = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("emp_joining_year")));
                        countList.Add(year);
                    }
                    return countList.Count();*/
            }
        }
    }
}
