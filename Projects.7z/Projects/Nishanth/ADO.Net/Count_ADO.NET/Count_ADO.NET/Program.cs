﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Count_ADO.NET
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter year to search:");
            int year = int.Parse(Console.ReadLine());
            Console.WriteLine("Count of Employees: " + CountEmployeeDAO.DisplayCount(year));
        }
    }
}
