/* Display all records from batch [DQL- Select]*/
select * from batch;

/* Update table data for example change BO of JV002 from Srini to Dinesh*/
update batch set batchowner='Dinesh' where batchid='CHN19JV002';

/* Delete a record from the table */
Delete from batch where batchid='CHN19JV001';

select * from trainee;
/*Q1; Display all trainees between 1002 to 1004 */
/* way1: Comparision operator */
select * from trainee where EmpId>=1002 and EmpId<=1004;
/* way2: Range operator */
select * from trainee where EmpId between 1002 and 1004;

/* Display all empId and traine name who are male */
select empid,empname from trainee where gender IN('male');

/* Display all empId and traine name who are not male */
select empid,empname from trainee where gender Not IN('male');

/* Display all empId and traine name who are male in ascending order by name*/
select empid,empname from trainee where gender IN('male')
order by empname; /* not require to write asc keyword as default order by is ascending */

/* Display all empId and traine name who are male in descending order by name*/
select empid,empname from trainee where gender IN('male')
order by empname desc;

select * from batch;
/* Display all batches whose batch owner name starts with D */
select * from batch where batchowner like 'D%';

/* Display all batches whose batch type does not ends with d */
select * from batch where batchtype Not like '%d';

/* Display all batches whose batch type does not ends with d 
and batchowner does not start with d in desc order by batchid*/
select * from batch where batchtype Not like '%d'
and batchowner not like 'D%' order by batchid desc;

use demoDb;

/* What is alias name for column: Its the name given in

select statement for display purpose only*/



/* Display the last 5 digits of batch with alias Batch_No,

Technology and BatchOwner as alias Coach where Coaches name

is >5 digits in length in asc order by name */

select substring(batchId,6,5) as Batch_No,

Technology,BatchOwner as Coach

from batch where len(batchowner)>5

order by batchowner;



/* Date Time Function */

/*1. Get Current date and time */

select getdate() as Current_Dat;

/*2. Extract the year,month and day value seperately from a datetime

value */

select day(getdate()) as Today_day,month(getdate()) as This_Month,

year(getdate()) as This_year;



/* Substract dates*/

select DATEDIFF(Day,getdate(),'09/22/2019') as Day_Diff,

DATEDIFF(Month,getdate(),'09/22/2019') as Month_Diff;



/* Add date information like add 5 days with current date and display the day info

after 5 days from current_date */

select DATEADD(day,5,getdate()) as Next_date;



/* Display the batchid,startdate,duration and the enddate for batches

which have joined in the month of june [where enddate=startdate+duration] */

select batchid,actualstartdate as startdate,

trainingduration as duration,

DATEADD(day,trainingduration,actualstartdate) as enddate

from batchdetails

where month(actualstartdate)=06;



