
insert into batch values
('CHN19DN011','OBL','.NET','Subasree','06/18/2019'),
('CHN19DN010','OBL','.NET','Subasree','06/18/2019'),
('CHN19DN019','OBL','.NET','Dafni','07/22/2019'),
('CHN19JV001','OBL','Java','Subasree','07/22/2019'),
('CHN19ID001','FSD','.NET FSD','Dinesh','06/18/2019'),
('CHN19ID002','FSD','.NET FSD','Dinesh','07/22/2019'),
('CHN19JV002','OBL','Java','Srini','07/22/2019');

insert into trainee values
(1001,'Sam',9600197755,'sam@gmail.com','Male'),
(1002,'Merry',9600197756,'merry@cognizant.com','Female'),
(1003,'Joe',9600197757,'joe@gmail.com','Male'),
(1004,'Peter',9600197758,'peter@cognizant.com','Male'),
(1005,'Sunjana',9600197759,'sanjana@yahoo.in','Female'),
(1006,'Henry',9600197710,'henry@cognizant.com','Male');


insert into batchdetails values
('CHN19DN011',1001,'Siruseri',90,'06/18/2019'),
('CHN19ID001',1003,'ASV',120,'06/25/2019'),
('CHN19DN011',1005,'Siruseri',90,'06/18/2019'),
('CHN19ID002',1006,'Siruseri',120,'07/28/2019');