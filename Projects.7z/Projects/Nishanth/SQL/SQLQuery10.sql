use demoDb;

select * from batch;
select * from trainee;

/* Find the batches that can be assigned to any trainee */
/* use Cross Join */
select batchid,empname from batch, trainee;

/* Display Employee Name,Phone,Email,Batch Id and batch type the trainee is taking
training */
select empname,phone,email,b.batchid,batchtype
from trainee tr join batchdetails bd
on tr.empid=bd.traineeid join
batch b on b.batchid=bd.batchid;

/* Display info about trainee who are allocated a batch and also not allocated a batch*/
/* Left outer join */
select * from trainee tr left outer join batchdetails bd
on tr.empid=bd.traineeid left outer join 
batch b on b.batchid=bd.batchid;

/* Display info about trainee who are allocated a batch. Display all batches even if
there is no trainee*/
/* Right outer join */
select * from trainee tr right outer join batchdetails bd
on tr.empid=bd.traineeid right outer join 
batch b on b.batchid=bd.batchid;

/* Display all trainees and all batch info whether conmmon data is there or not */
select * from trainee tr full outer join batchdetails bd
on tr.empid=bd.traineeid full outer join 
batch b on b.batchid=bd.batchid;

select * from trainee;
alter table trainee add PocId int;
update trainee set pocId=1002;
update trainee set pocId=1001 where empid=1004;
update trainee set pocid=null where empid=1002;
update trainee set pocid=null where empid=1001;

/* Display the empid  and name of person who is working as POC */
select distinct emp1.empid,emp1.empname
from trainee emp1 join trainee emp2
on emp1.empid=emp2.pocid;

