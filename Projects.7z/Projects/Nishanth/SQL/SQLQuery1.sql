create database demoDb;
use demoDb;

create table batch
(
BatchId varchar(100),
BatchType varchar(100) not null,
Technology varchar(100) not null,
BatchOwner varchar(100),
StartDate date,
constraint BatchID_PK primary key(BatchId)
);

create table trainee
(
EmpId bigint,
EmpName varchar(100),
Phone bigint not null,
Email varchar(100),
Gender varchar(100),
constraint EmpId_PK primary key(EmpID),
constraint Phone_UQ unique(Phone)
);

/* Alter Statement */
Alter table trainee add constraint Email_UQ unique(Email);

create table batchDetails
(
BatchId varchar(100) not null,
TraineeId bigint,
Location varchar(100),
TrainingDuration int,
ActualStartDate date,
constraint BatchID_FK foreign key(BatchId) references batch(BatchId) on delete cascade on update cascade,
constraint TraineeID_FK foreign key(TraineeId) references trainee(EmpId) on delete cascade on update cascade
)

/* Table Structure */
sp_help batchDetails;
sp_help trainee;



