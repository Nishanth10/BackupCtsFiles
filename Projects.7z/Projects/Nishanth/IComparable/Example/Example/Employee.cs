﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example
{
    class Employee:IComparable<Employee>
    {
        private int _id;
        private string _name;

        public Employee()
        {

        }

        public Employee(int _id, string _name)
        {
            this._id = _id;
            this._name = _name;
        }

        public int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public int CompareTo(Employee other)
        {
            //Sort data in list of class objects via name in desc order
            int result = other.Name.CompareTo(this.Name);

            if (result == 0) // if same name exist
            {
                return this.Id.CompareTo(other.Id);
            }
            else
            {
                return other.Name.CompareTo(this.Name);
            }
        }

        public override string ToString()
        {
            return string.Format("{0,-20}{1}", this.Id, this.Name);
        }
    }
}
