﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAO;
using com.cognizant.truyum.model;
using com.cognizant.truyum.util;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            lblAdminId.Text = Session["adminId"].ToString();
            gridCustomer.Visible = false;
            DisplayData();
        }
    }

    protected void radioEditCustomer_CheckedChanged(object sender, EventArgs e)
    {
        if(radioEditCustomer.Checked==true)
        {
            radioMenuItems.Checked = false;
            gridCustomer.Visible = true;
        }
    }

    protected void radioMenuItems_CheckedChanged(object sender, EventArgs e)
    {
        if(radioMenuItems.Checked==true)
        {
            radioEditCustomer.Checked = false;
            Response.Redirect("MenuItemListAdmin.aspx");
        }
    }

    protected void EditCustomerData(object sender, GridViewEditEventArgs e)
    {
        //Create a row in grid for searching the edition
        GridViewRow row = gridCustomer.Rows[e.NewEditIndex];
        //extract item ID present in column 0 from grid       
        string userId = row.Cells[0].Text;       
        Response.Redirect("EditUserInfo.aspx?ItemId=" + userId);
    }

    protected void DisplayData()
    {
        AdminUserBL ad = new AdminUserBL();
        List<com.cognizant.truyum.model.User> userList =
            ad.DisplayUser();
        gridCustomer.DataSource = userList;
        gridCustomer.DataBind();
    }
}