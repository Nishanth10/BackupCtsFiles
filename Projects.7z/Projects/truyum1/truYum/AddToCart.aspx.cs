﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAO;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lblMessage.Text = "";
            DisplayItems();
            lblUserId.Text = Session["userId"].ToString();
        }
    }

    protected void grdItem_AddButtonClick(object sender, GridViewCommandEventArgs e)
    {
        //find the row number for whose button you are clicking
        int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
        //through row number extract item id
        string itemItemId = gridItem.Rows[gridviewrowindex].Cells[0].Text;
        CartDaoSql CartDaoSql = new CartDaoSql();
        CartDaoSql.AddCartItem(int.Parse(lblUserId.Text), long.Parse(itemItemId));
        lblMessage.Text = "Item Added to cart successfully";
    }
    public void DisplayItems()
    {
        MenuItemDaoSQL MenuItemDaoSQL = new MenuItemDaoSQL();
        List<com.cognizant.truyum.model.MenuItem> menuList = MenuItemDaoSQL.GetMenuItemListCustomer();
        gridItem.DataSource = menuList;
        gridItem.DataBind();
    }
}