﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//namespace
using DAO;
using com.cognizant.truyum.model;

public partial class _Default : System.Web.UI.Page
{
    //call the CartDaoCollection class
  
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            lblUserId.Text = Session["userId"].ToString();
            displayData();
        }
       
            
    }

    
   

    protected void displayData()
    {
        try
        {
            CartDaoSql CartDaoSql = new CartDaoSql();
            gridCart.DataSource = CartDaoSql.GetAllCartItems(long.Parse(lblUserId.Text)).MenuItemList;
            gridCart.DataBind();
            TotalPrice();

        }
        catch(CartEmptyException)
        {
            Response.Redirect("CartEmpty.aspx");
        }
    }

    protected void TotalPrice()
    {
        CartDaoSql CartDaoSql = new CartDaoSql();
         //get all info from cart for user id 1
         Cart cart = CartDaoSql.GetAllCartItems(long.Parse(lblUserId.Text));

        lblTotalPrice.Text = cart.Total.ToString();
    }

    protected void Delete_Click(object sender, GridViewCommandEventArgs e)
    {
        CartDaoSql CartDaoSql = new CartDaoSql();
        //Delete data when user clicks delete command button
        //find the row index [ie from which row you have clicked the button
        int rowindex = int.Parse(e.CommandArgument.ToString());
        //from the row extract the item id against which you will delete data
        string itemId = gridCart.Rows[rowindex].Cells[0].Text;
        CartDaoSql.RemoveCartItem(long.Parse(lblUserId.Text), long.Parse(itemId));
        lblMessage.Text = "Item removed from Cart successfully";
        
    }

    protected void Display_Data(object sender, GridViewDeleteEventArgs e)
    {
        displayData();
    }
}