﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.truyum.model
{
    public class MenuItem
    {
        private int _id;
        private string _name;
        private float _price;
        private bool _active;
        private DateTime _dateOfLaunch;
        private string _category;
        private bool _freeDelivery;

        public int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public float Price
        {
            get
            {
                return _price;
            }

            set
            {
                _price = value;
            }
        }

        public bool Active
        {
            get
            {
                return _active;
            }

            set
            {
                _active = value;
            }
        }

        public DateTime DateOfLaunch
        {
            get
            {
                return _dateOfLaunch;
            }

            set
            {
                _dateOfLaunch = value;
            }
        }

        public string Category
        {
            get
            {
                return _category;
            }

            set
            {
                _category = value;
            }
        }

        public bool FreeDelivery
        {
            get
            {
                return _freeDelivery;
            }

            set
            {
                _freeDelivery = value;
            }
        }

        public MenuItem()
        {
        }

        public MenuItem(int _id, string _name, float _price, bool _active, DateTime _dateOfLaunch, string _category, bool _freeDelivery)
        {
            this.Id = _id;
            this.Name = _name;
            this.Price = _price;
            this.Active = _active;
            this.DateOfLaunch = _dateOfLaunch;
            this.Category = _category;
            this.FreeDelivery = _freeDelivery;
        }
        public override string ToString()
        {
            return string.Format("{0,-10}{1,-10}{2,-10}{3,-10}{4,-10}{5,-10}{6}",
                this._id, this._name, this._price, this._active==true?"Yes":"No",
                this._dateOfLaunch.ToString("dd/MM/yyyy"),
                this._category, this._freeDelivery==true?"Yes":"No");
        }

        //override bool equals to compare id between 2 class objects
        public override bool Equals(object obj)
        {
            //check for data existing or not
            if(obj==null)
            {
                return false;
            }
            else
            {
                //Create a class object and map it to obj
                MenuItem menu = (MenuItem)obj;
                return (this.Id.Equals(menu.Id));
            }

        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }



    }
}
