﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//namespace
using System.Data;
using System.Data.SqlClient;
//namespace for model
using com.cognizant.truyum.model;
using DAO;
namespace DAO
{
    public class CartDaoSql:ICartDao
    {
        static string callConnection = ConnectionHandler.ConnectionVariable;
        public static string addCartData = "INSERT INTO [cart] (ct_us_id, ct_me_id) VALUES(@userid,@menuid)";
        public static string getAllCartItems = "SELECT * FROM [menu_item] m JOIN [cart] c ON m.me_id = c.ct_me_id AND c.ct_us_id = @id;";
        public static string countTotal = "SELECT SUM(m.me_price) as Total_Price FROM [menu_item] m JOIN [cart] c ON m.me_id = c.ct_me_id AND c.ct_us_id = @id;";
        public static string deleteItem= "DELETE FROM [cart] WHERE ct_us_id = @userid AND ct_me_id = @menuid;";

        public void AddCartItem(long userId, long productId)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = addCartData
                };

                cmd.Parameters.Add("@userid", SqlDbType.Int).Value = userId;
                cmd.Parameters.Add("@menuid", SqlDbType.Int).Value = productId;

                cmd.ExecuteNonQuery();
            }
        }
        public Cart GetAllCartItems(long userId)
        {
            Cart cart = new Cart();
            List<MenuItem> menuList = new List<MenuItem>();

            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = getAllCartItems
                };

                cmd.Parameters.Add("@id", SqlDbType.Int).Value = userId;

                SqlDataReader dr = cmd.ExecuteReader();
                int count = 0;
                while (dr.Read())
                {
                    MenuItem menu = new MenuItem();
                    menu.Id = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("me_id")));
                    menu.Name = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_name")));
                    menu.Price = Convert.ToSingle(dr.GetValue(dr.GetOrdinal("me_price")));
                    menu.Active = (Convert.ToString(dr.GetValue(dr.GetOrdinal("me_active"))).
                        Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);
                    menu.DateOfLaunch = Convert.ToDateTime(dr.GetValue(dr.GetOrdinal("me_date_of_launch")));
                    menu.Category = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_category")));
                    menu.FreeDelivery = (Convert.ToString(dr.GetValue(dr.GetOrdinal("me_free_delivery"))).
                        Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);

                    menuList.Add(menu);
                    count++;
                }

                dr.Close();
                if (count == 0) //ie no item is there in cart
                {
                    throw new CartEmptyException();
                }
                cart.MenuItemList = menuList;

                SqlCommand cmd1 = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = countTotal
                };

                cmd1.Parameters.Add("@id", SqlDbType.Int).Value = userId;

                SqlDataReader dr1 = cmd1.ExecuteReader();

                while (dr1.Read())
                {
                    cart.Total = Convert.ToDouble(dr1.GetValue(dr1.GetOrdinal("Total_Price")));
                }

                return cart;
            }
        }
         
        
        public void RemoveCartItem(long userId,long productId)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = deleteItem
                };

                cmd.Parameters.Add("@userid", SqlDbType.Int).Value = userId;
                cmd.Parameters.Add("@menuid", SqlDbType.Int).Value = productId;

                cmd.ExecuteNonQuery();
            }
        }

        }
}
