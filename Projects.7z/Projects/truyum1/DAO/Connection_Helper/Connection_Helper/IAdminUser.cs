﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.truyum.model;

namespace DAO
{
    interface IAdminUser
    {
        int UserRegistration(string name, string password, long phone);
        int UserLogin(int userId, string password);
        int AdminLogin(int adminId, string password);

        List<User> DisplayUser();

        User DisplaySpecificUser(string password);

        User DisplaySpecficUserById(int id);
        int EditUserInfo(string status,int userId);

    }
}
