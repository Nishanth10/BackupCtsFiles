﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using com.cognizant.movie.model;

namespace com.cognizant.movie.dao {
    public class MovieDaoSqlImpl : IMovieDao {
        public static string _callconnection = ConnectionHandler.GetConnection;
        public static string _getDataAdmin = "SELECT * FROM movie";
        public static string _getDataCustomer = "SELECT * FROM movie WHERE mv_date_of_launch > GETDATE() AND mv_active='Yes'";
        public static string _getMovieById = "SELECT * FROM movie WHERE mv_id=@Id;";
        public static string _updateMovie = "UPDATE movie SET mv_title=@title, mv_budget=@budget, mv_active=@active, mv_date_of_launch=@dateoflaunch, mv_genre=@genre, mv_has_teaser =@hasteaser WHERE mv_id =@Id";

        public List<Movie> GetMovieListAdmin() {
            List<Movie> movieList = new List<Movie>();
            using (SqlConnection sqlConnnection = new SqlConnection(_callconnection)) {
                sqlConnnection.Open();
                SqlCommand command = new SqlCommand {
                    Connection = sqlConnnection,
                    CommandType = CommandType.Text,
                    CommandText = _getDataAdmin
                };

                SqlDataReader dataReader = command.ExecuteReader();
                while (dataReader.Read()) {
                    Movie movie = new Movie();
                    movie.Id = Convert.ToInt32
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_id")));
                    movie.Title = Convert.ToString
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_title")));
                    movie.Budget = Convert.ToSingle
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_budget")));
                    movie.Active = (Convert.ToString
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_active"))).
                        Equals("yes", StringComparison.InvariantCultureIgnoreCase)
                        ? true : false);
                    movie.DateOfLaunch = Convert.ToDateTime
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_date_of_launch")));
                    movie.Genre = Convert.ToString
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_genre")));
                    movie.HasTeaser = (Convert.ToString
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_has_teaser"))).
                        Equals("yes", StringComparison.InvariantCultureIgnoreCase)
                        ? true : false);

                    movieList.Add(movie);
                }

                return movieList;
            }
        }

        public List<Movie> GetMovieListCustomer() {
            List<Movie> movieList = new List<Movie>();
            using (SqlConnection sqlConnnection = new SqlConnection(_callconnection)) {
                sqlConnnection.Open();
                SqlCommand command = new SqlCommand {
                    Connection = sqlConnnection,
                    CommandType = CommandType.Text,
                    CommandText = _getDataCustomer
                };

                SqlDataReader dataReader = command.ExecuteReader();
                while (dataReader.Read()) {
                    Movie movie = new Movie();
                    movie.Id = Convert.ToInt32
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_id")));
                    movie.Title = Convert.ToString
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_title")));
                    movie.Budget = Convert.ToSingle
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_budget")));
                    movie.Active = (Convert.ToString
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_active"))).
                        Equals("yes", StringComparison.InvariantCultureIgnoreCase)
                        ? true : false);
                    movie.DateOfLaunch = Convert.ToDateTime
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_date_of_launch")));
                    movie.Genre = Convert.ToString
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_genre")));
                    movie.HasTeaser = (Convert.ToString
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_has_teaser"))).
                        Equals("yes", StringComparison.InvariantCultureIgnoreCase)
                        ? true : false);

                    movieList.Add(movie);
                }

                return movieList;
            }
        }

        public Movie GetMovie(long movieId) {
            using (SqlConnection sqlConnnection = new SqlConnection(_callconnection)) {
                sqlConnnection.Open();
                SqlCommand command = new SqlCommand {
                    Connection = sqlConnnection,
                    CommandType = CommandType.Text,
                    CommandText = _getMovieById
                };

                command.Parameters.Add("@Id", SqlDbType.Int).Value = movieId;
                SqlDataReader dataReader = command.ExecuteReader();
                Movie movie = new Movie();
                while (dataReader.Read()) {
                    movie.Id = Convert.ToInt32
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_id")));
                    movie.Title = Convert.ToString
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_title")));
                    movie.Budget = Convert.ToSingle
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_budget")));
                    movie.Active = (Convert.ToString
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_active"))).
                        Equals("yes", StringComparison.InvariantCultureIgnoreCase)
                        ? true : false);
                    movie.DateOfLaunch = Convert.ToDateTime
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_date_of_launch")));
                    movie.Genre = Convert.ToString
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_genre")));
                    movie.HasTeaser = (Convert.ToString
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_has_teaser"))).
                        Equals("yes", StringComparison.InvariantCultureIgnoreCase)
                        ? true : false);
                }

                return movie;
            }
        }

        public void ModifyMovie(Movie movie) {
            using (SqlConnection sqlConnnection = new SqlConnection(_callconnection)) {
                sqlConnnection.Open();
                SqlCommand command = new SqlCommand {
                    Connection = sqlConnnection,
                    CommandType = CommandType.Text,
                    CommandText = _updateMovie
                };

                command.Parameters.Add("@title", SqlDbType.VarChar).Value = movie.Title;
                command.Parameters.Add("@budget", SqlDbType.Decimal).Value = movie.Budget;
                command.Parameters.Add("@active", SqlDbType.VarChar).Value = 
                    (movie.Active == true) ? "Yes" : "No";
                command.Parameters.Add("@dateoflaunch", SqlDbType.Date).Value =
                    movie.DateOfLaunch;
                command.Parameters.Add("@genre", SqlDbType.VarChar).Value = movie.Genre;
                command.Parameters.Add("@hasteaser", SqlDbType.VarChar).Value
                    = (movie.HasTeaser == true) ? "Yes" : "No";
                command.Parameters.Add("@Id", SqlDbType.Int).Value = movie.Id;
                command.ExecuteNonQuery();
            }
        }
    }
}
