﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.movie.dao;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if (!IsPostBack) {
            DisplayMovies();
            lblUserId.Text = Session["userId"].ToString();
        }
    }

    protected void GridMovieAddButtonClick(object sender, GridViewCommandEventArgs e) {
        int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
        string movieId = gridMovie.Rows[gridviewrowindex].Cells[0].Text;
        Session["userId"] = lblUserId.Text.ToString();
        Response.Redirect("AddToFavorites.aspx?movieId=" + movieId);
    }

    protected void DisplayMovies() {
        MovieDaoSqlImpl movieDao = new MovieDaoSqlImpl();
        List<com.cognizant.movie.model.Movie> movieList = movieDao.GetMovieListCustomer();
        gridMovie.DataSource = movieList;
        gridMovie.DataBind();
    }

    protected void GridMovieRowDataBound(object sender, GridViewRowEventArgs e) {
        if (e.Row.Cells[3].Text == "True") {
            e.Row.Cells[3].Text = "Yes";
        }
        if (e.Row.Cells[3].Text == "False") {
            e.Row.Cells[3].Text = "No";
        }
        if (e.Row.Cells[6].Text == "True") {
            e.Row.Cells[6].Text = "Yes";
        }
        if (e.Row.Cells[6].Text == "False") {
            e.Row.Cells[6].Text = "No";
        }
        float f;
        if (float.TryParse(e.Row.Cells[2].Text, out f)) {
            e.Row.Cells[2].Text = "$" + "&nbsp;" + ((double)f).ToString();
        }
    }

    protected void FavoriteBtn_Click(object sender, EventArgs e)
    {
        Session["userId"] = lblUserId.Text.ToString();
        Response.Redirect("Favorite.aspx");
    }

}
