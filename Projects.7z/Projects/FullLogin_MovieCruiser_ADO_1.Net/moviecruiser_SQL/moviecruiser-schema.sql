CREATE DATABASE moviecruiser1;

USE moviecruiser1;

-- User Table
CREATE TABLE [dbo].[user](
       [us_id] [bigint] IDENTITY(1,1) NOT NULL,
       [us_name] [varchar](100) NULL,
       [us_password] [varchar](100) unique,
       [us_phone] [bigint],
       [us_active] [varchar](60),
CONSTRAINT [PK_user] PRIMARY KEY CLUSTERED 
(
       [us_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

create table [dbo].[admin]
(
[ad_id] [bigint] IDENTITY(1001,1) NOT NULL,
[ad_password] [varchar](100) unique,
constraint ad_id_pk primary key(ad_id)
);

insert into admin values
('admin1'),
('admin2'),
('admin3');

--movie table
CREATE TABLE movie (
mv_id bigint IDENTITY(1,1) NOT NULL,
mv_title varchar(100) NULL,
mv_budget decimal(12,2) NULL,
mv_active varchar(3) NULL,
mv_date_of_launch date NULL,
mv_genre varchar(45) NULL,
mv_has_teaser varchar(3) NULL,
CONSTRAINT PK_movie PRIMARY KEY(mv_id)); 

--favorite table
CREATE TABLE favorite (
fv_id bigint identity(1,1) NOT NULL,
fv_us_id bigint NULL,
fv_mv_id bigint NULL,
CONSTRAINT PK_favorite PRIMARY KEY(fv_id)); 

alter table favorite add constraint FK_fv_us foreign key(fv_us_id) 
references [user](us_id) on delete cascade on update cascade;

alter table favorite add constraint FK_fv_mv foreign key(fv_mv_id) 
references movie(mv_id) on delete cascade on update cascade; 
 
