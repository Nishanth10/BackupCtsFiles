﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.movie.model
{
    public class User
    {
        private int userId;
        private string name;
        private string password;
        private long phone;
        private string activationStatus;

        public User()
        {

        }

        public User(int userId, string name, string password, long phone, string activationStatus)
        {
            this.userId = userId;
            this.name = name;
            this.password = password;
            this.phone = phone;
            this.activationStatus = activationStatus;
        }

        public int UserId
        {
            get
            {
                return userId;
            }

            set
            {
                userId = value;
            }
        }

        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }

        public long Phone
        {
            get
            {
                return phone;
            }

            set
            {
                phone = value;
            }
        }

        public string ActivationStatus
        {
            get
            {
                return activationStatus;
            }

            set
            {
                activationStatus = value;
            }
        }

       
    }
}
