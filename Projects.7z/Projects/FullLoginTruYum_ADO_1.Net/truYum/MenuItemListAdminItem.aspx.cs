﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//refer to the DAO
using Com.Cognizant.Truyum.Dao;
//Create a dataset to hold a record collected from DAO method
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DisplayItemsAdmin();
        }
    }

    protected void gridItem_EditRow(object sender, GridViewEditEventArgs e)
    {
        //Create a row in grid for searching the edition
        GridViewRow row = gridItem.Rows[e.NewEditIndex];
        //extract item id present in column 0 from grid
        string itemId = row.Cells[0].Text;
        //string name = row.Cells[1].Text;
        //string price = row.Cells[2].Text;
        //string dateofLaunch = row.Cells[4].Text;
        Response.Redirect("EditMenuItem.aspx?ItemId="+itemId); //+"&Name="+name+"&Price="+price+"&DateofLaunch="+dateofLaunch
    }

    protected void gridItem_CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gridItem.EditIndex = -1;
    }

    protected void DisplayItemsAdmin()
    {
        MenuItemDaoSql menuItemDaoSql = new MenuItemDaoSql();
        List<Com.Cognizant.Truyum.Model.MenuItem> menuList = menuItemDaoSql.GetMenuItemListAdmin();
        gridItem.DataSource = menuList;
        gridItem.DataBind();
    }

    protected void gridItem_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.Cells[3].Text == "True")
        {
            e.Row.Cells[3].Text = "Yes";
        }
        if (e.Row.Cells[3].Text == "False")
        {
            e.Row.Cells[3].Text = "No";
        }
        if (e.Row.Cells[6].Text == "True")
        {
            e.Row.Cells[6].Text = "Yes";
        }
        if (e.Row.Cells[6].Text == "False")
        {
            e.Row.Cells[6].Text = "No";
        }
    }
}