﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Truyum.Dao;
using Com.Cognizant.Truyum.Model;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                lblLoginPassword.Text = Session["PasswordInfo"].ToString();
                if (lblLoginPassword.Text != "" || lblLoginPassword.Text != null)
                {
                    AdminUserBL ad = new AdminUserBL();
                    Com.Cognizant.Truyum.Model.User user =
                        ad.DisplaySpecificUser(lblLoginPassword.Text);

                    lblLoginId.Text = user.UserId.ToString();
                }
            }
        }
        catch(Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}