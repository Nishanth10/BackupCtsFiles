﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Truyum.Dao;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            DisplayItems();
            lblUserId.Text = Session["userId"].ToString();
        }
    }

    protected void gridItem_AddButtonClick(object sender, GridViewCommandEventArgs e)
    {
        //find the row number for whose button you are clicking
        int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
        //through row number extract item id
        string menuItemId = gridItem.Rows[gridviewrowindex].Cells[0].Text;
        Response.Redirect("AddToCart.aspx?menuItemId=" + menuItemId);
        Session["userId"] = lblUserId.Text.ToString();
        Response.Redirect("AddToCart.aspx?menuItemId=" + menuItemId); 
   
    }

    public void DisplayItems()
    {
        MenuItemDaoSql menuItemDaoSql = new MenuItemDaoSql();
        List<Com.Cognizant.Truyum.Model.MenuItem> menuList = menuItemDaoSql.GetMenuItemListCustomer();
        gridItem.DataSource = menuList;
        gridItem.DataBind();
    }

    protected void gridChangeValue(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.Cells[2].Text == "True")
        {
            e.Row.Cells[2].Text = "Yes";
        }
        if (e.Row.Cells[2].Text == "False")
        {
            e.Row.Cells[2].Text = "No";
        }
    }

    protected void cartBtn_Click_Click(object sender, EventArgs e)
    {
        Session["userId"] = lblUserId.Text.ToString();
        Response.Redirect("Cart.aspx");
    }
}