﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Truyum.Dao;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            AdminPanel.Visible = false;
            UserPanel.Visible = false;
            lblMessage.Visible = false;
        }
    }


    protected void radiaAdmin_CheckedChanged(object sender, EventArgs e)
    {
        if (radiaAdmin.Checked == true)
        {
            AdminPanel.Visible = true;
            UserPanel.Visible = false;
            radioUser.Checked = false;
        }
    }

    protected void radioUser_CheckedChanged(object sender, EventArgs e)
    {
        if (radioUser.Checked == true)
        {
            UserPanel.Visible = true;
            AdminPanel.Visible = false;
            radiaAdmin.Checked = false;
        }
    }

    protected void btnAdminLogin_Click(object sender, EventArgs e)
    {
        AdminUserBL ad = new AdminUserBL();
        int result = ad.AdminLogin
            (int.Parse(txtAdminId.Text), txtAdminPassword.Text);
        if (result > 0) //ie adminId and password matches
        {
            Session["adminId"] = txtAdminId.Text;
            Response.Write
("<script>alert('Welcome Admin');window.location.href='AdminProcess.aspx'</script>");
        }
        else //userId or Password not found
        {
            Response.Write
("<script>alert('Invalid Credentials..Try again')</script>");
            //Clear old contents from textboxes to write credentials again
            txtAdminId.Text = "";
            txtAdminPassword.Text = "";
            //position write cursor automatically on userIdtxtbox
            txtAdminId.Focus();
        }
    }

    protected void btnUserLogin_Click(object sender, EventArgs e)
    {
        AdminUserBL ad = new AdminUserBL();
        int result = ad.UserLogin
            (int.Parse(txtUserId.Text), txtUserPassword.Text);
        if (result == 1) 
        {
            lblMessage.Visible = false;
            lblMessage.Text = "";
            Session["userId"] = txtUserId.Text;
            Response.Write
("<script>alert('Welcome User');window.location.href='MenuItemListCustomer.aspx'</script>");
        }
        if (result == 2)
        {
            lblMessage.Visible = true;
            lblMessage.Text = "User status Inactive..Try after some time";
        }
        if (result == 3)
        {
            lblMessage.Visible = true;
            lblMessage.Text = "Invalid Credential..Try Again";
            txtUserId.Text = "";
            txtUserPassword.Text = "";
            txtUserId.Focus();
        }
    }
}