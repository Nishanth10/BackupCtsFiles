﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Truyum.Dao;
using Com.Cognizant.Truyum.Utility;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            lblId.Text = Request.QueryString["ItemId"].ToString();
            /*txtName.Text = Request.QueryString["Name"].ToString();
            txtPrice.Text = Request.QueryString["Price"].ToString();
            txtDateOfLaunch.Text = Request.QueryString["DateofLaunch"].ToString();*/
            ddlCategory.Items.Add("Select Item");
            ddlCategory.Items.Add("Main Course");
            ddlCategory.Items.Add("Starters");
            ddlCategory.Items.Add("Dessert");
            ddlCategory.Items.Add("Drinks");
            if (lblId.Text != null || lblId.Text!="") //ie id is found
            {
                MenuItemDaoSql menuItemDaoSql = new MenuItemDaoSql();
                Com.Cognizant.Truyum.Model.MenuItem menu = 
                    menuItemDaoSql.GetMenuItem(long.Parse(lblId.Text));

                //fill the data in the controls through menu class properties
                txtName.Text = menu.Name;
                txtPrice.Text = menu.Price.ToString();
                txtDateOfLaunch.Text = menu.DateOfLaunch.ToString("dd/MM/yyyy");
                //check if the menuItem is having active yes or no
                if(menu.Active==true)
                {
                    radioActiveYes.Checked = true;
                }
                else
                {
                    radioActiveNo.Checked = true;
                }
                //check if delivery is given
                chkFreeDelivery.Checked = menu.FreeDelivery;

                //Item present by admin in dropdown
                ddlCategory.SelectedItem.Text = menu.Category;

            }

        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        //save the edited info back to collection
        Com.Cognizant.Truyum.Model.MenuItem menu= 
            new Com.Cognizant.Truyum.Model.MenuItem();
        menu.Id = int.Parse(lblId.Text);
        menu.Name = txtName.Text;
        menu.Price = long.Parse(txtPrice.Text);
        menu.DateOfLaunch = DateUtility.convertToDate(txtDateOfLaunch.Text);
        menu.Category = ddlCategory.SelectedItem.Text;
        if(radioActiveYes.Checked==true)
        {
            radioActiveNo.Checked = false;
            menu.Active = true;
        }
        else
        {
            radioActiveNo.Checked = true;
            menu.Active = false;
        }
        if(chkFreeDelivery.Checked==true)
        {
            menu.FreeDelivery = true;
        }
        else
        {
            menu.FreeDelivery = false;
        }

        //call the modify method 
        MenuItemDaoSql menuItemDaoSql = new MenuItemDaoSql();
        menuItemDaoSql.ModifyMenuItem(menu);
        Response.Redirect("EditMenuItemStatus.aspx");
    }

    protected void radioActiveYes_CheckedChanged(object sender, EventArgs e)
    {
        if(radioActiveYes.Checked==true)
        {
            radioActiveNo.Checked= false;
        }
    }

    protected void radioActiveNo_CheckedChanged(object sender, EventArgs e)
    {
        if (radioActiveNo.Checked == true)
        {
            radioActiveYes.Checked = false;
        }
    }
}