﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Truyum.Dao;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            lblAdminId.Text = Session["adminId"].ToString();
            gridCustomer.Visible = false;
            DisplayData();
        }
    }

    protected void radioEditCustomer_CheckedChanged(object sender, EventArgs e)
    {
        if(radioEditCustomer.Checked==true)
        {
            radioMenuItem.Checked = false;
            gridCustomer.Visible = true;
        }
    }

    protected void radioMenuItem_CheckedChanged(object sender, EventArgs e)
    {
        if(radioMenuItem.Checked==true)
        {
            radioEditCustomer.Checked = false;
            Response.Redirect("MenuItemListAdminitem.aspx");
        }
    }

    protected void editCustomerData(object sender, GridViewEditEventArgs e)
    {
        //Create a row in grid for searching the edition
        GridViewRow row = gridCustomer.Rows[e.NewEditIndex];
        //extract item id present in column 0 from grid
        string userId = row.Cells[0].Text;
        //string name = row.Cells[1].Text;
        //string price = row.Cells[2].Text;
        //string dateofLaunch = row.Cells[4].Text;
        Response.Redirect("EditUserInfo.aspx?userId=" + userId); 
    }

    protected void DisplayData()
    {
        AdminUserBL ad = new AdminUserBL();
        List<Com.Cognizant.Truyum.Model.User> userList = ad.DisplayUser();
        gridCustomer.DataSource = userList;
        gridCustomer.DataBind();
    }
}