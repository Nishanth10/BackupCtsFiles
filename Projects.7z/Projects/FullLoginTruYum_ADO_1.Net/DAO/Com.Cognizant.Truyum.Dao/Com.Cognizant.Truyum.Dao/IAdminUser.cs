﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Com.Cognizant.Truyum.Model;

namespace Com.Cognizant.Truyum.Dao
{
    interface IAdminUser
    {
        int UserRegistration(string name, string password, long phone);
        int UserLogin(int userId, string password);
        int AdminLogin(int adminId, string password);
        List<User> DisplayUser();
        User DisplaySpecificUser(string password);
        int EditUserInfo(string status,int userId);
    }
}
