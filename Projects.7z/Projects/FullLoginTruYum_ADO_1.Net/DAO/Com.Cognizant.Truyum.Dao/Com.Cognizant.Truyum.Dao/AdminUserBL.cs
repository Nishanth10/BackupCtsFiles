﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Com.Cognizant.Truyum.Model;

namespace Com.Cognizant.Truyum.Dao
{
    public class AdminUserBL : IAdminUser
    {
        static string callConnection = ConnectionHandler.ConnectionVariable;
        static string registerUser = "INSERT INTO [dbo].[user] (us_name,us_password,us_phone,us_active) VALUES (@name,@password,@phone,@active);";
        static string displayFilteredUser = "select * from [user] where us_password=@password;";
        static string loginAdmin = "select * from admin;";
        static string userDetails = "select * from [user];";
        static string displayFilteredUserByID = "select * from [user] where us_id=@id;";
        static string updateUser = "update [user] set us_active=@active where us_id=@id;";

        public int AdminLogin(int adminId, string password)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = loginAdmin
                };

                //Read data one by one from table and match with user supplied
                //userid and password
                SqlDataReader dr = cmd.ExecuteReader();
                int logResult = 0;
                while (dr.Read())
                {
                    if (Convert.ToInt32(dr.GetValue(dr.GetOrdinal("ad_id"))).
                        Equals(adminId)
                        &&
                    Convert.ToString(dr.GetValue(dr.GetOrdinal("ad_password"))).
                    Equals(password))
                    {
                        logResult = 1;
                        break;
                    }
                }
                return logResult;
            }
        }

        public User DisplaySpecificUser(string password)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = displayFilteredUser
                };

                cmd.Parameters.Add("@password", SqlDbType.VarChar).Value = password;

                SqlDataReader dr = cmd.ExecuteReader();
                User user = new User();

                while (dr.Read())
                {
                    user.UserId = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("us_id")));
                    user.Name = Convert.ToString(dr.GetValue(dr.GetOrdinal("us_name")));
                    user.Password = Convert.ToString(dr.GetValue(dr.GetOrdinal("us_password")));
                    user.Phone = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("us_phone")));
                    user.ActivationStatus = Convert.ToString(dr.GetValue(dr.GetOrdinal("us_active")));
                }
                return user;
            }
        }

        public List<User> DisplayUser()
        {
            List<User> userList = new List<User>();
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = userDetails
                };

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    User user = new User();
                    user.UserId = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("us_id")));
                    user.Name = Convert.ToString(dr.GetValue(dr.GetOrdinal("us_name")));
                    user.Password = Convert.ToString(dr.GetValue(dr.GetOrdinal("us_password")));
                    user.Phone = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("us_phone")));
                    user.ActivationStatus = Convert.ToString(dr.GetValue(dr.GetOrdinal("us_active")));
                    userList.Add(user);
                }
                return userList;

            }
        }

        public int EditUserInfo(string status,int userId)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = updateUser
                };
                cmd.Parameters.Add("@active", SqlDbType.VarChar).Value = status;
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = userId;
                result = cmd.ExecuteNonQuery();
            }
            return result;
        }

        public int UserLogin(int userId, string password)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = userDetails
                };

                //Read data one by one from table and match with user supplied
                //userid and password
                SqlDataReader dr = cmd.ExecuteReader();
                int logResult = 0;
                while (dr.Read())
                {
                    //UserId and Password Found, Also status is active Login
                    if (Convert.ToInt32(dr.GetValue(dr.GetOrdinal("us_id"))).
                        Equals(userId)
                        &&
                    Convert.ToString(dr.GetValue(dr.GetOrdinal("us_password"))).
                    Equals(password)
                    &&
                    Convert.ToString(dr.GetValue(dr.GetOrdinal("us_active"))).
                    Equals("yes", StringComparison.InvariantCultureIgnoreCase))
                    {
                        logResult = 1;
                        break;
                    }
                    //UserId and Password Found, Status is Inactive Login Restricted
                    else if (Convert.ToInt32(dr.GetValue(dr.GetOrdinal("us_id"))).
                         Equals(userId)
                         &&
                     Convert.ToString(dr.GetValue(dr.GetOrdinal("us_password"))).
                     Equals(password)
                     &&
                     Convert.ToString(dr.GetValue(dr.GetOrdinal("us_active"))).
                     Equals("no", StringComparison.InvariantCultureIgnoreCase))
                    {
                        logResult = 2;
                        break;
                    }
                    //UserId or password not found
                    else
                    {
                        logResult = 3;
                    }
                }
                return logResult;
            }
        }

        public int UserRegistration(string name, string password, long phone)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = registerUser
                };

                cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = name;
                cmd.Parameters.Add("@password", SqlDbType.VarChar).Value = password;
                cmd.Parameters.Add("@phone", SqlDbType.BigInt).Value = phone;
                cmd.Parameters.Add("@active", SqlDbType.VarChar).Value = "No";

                result = cmd.ExecuteNonQuery();
            }
            return result;
        }

        public User DisplaySpecficUserById(int id)
        {
            using (SqlConnection con = new SqlConnection(callConnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = displayFilteredUserByID
                };

                cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = id;

                SqlDataReader dr = cmd.ExecuteReader();
                User user = new User();

                while (dr.Read())
                {
                    user.UserId = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("us_id")));
                    user.Name = Convert.ToString(dr.GetValue(dr.GetOrdinal("us_name")));
                    user.Password = Convert.ToString(dr.GetValue(dr.GetOrdinal("us_password")));
                    user.Phone = Convert.ToInt64(dr.GetValue(dr.GetOrdinal("us_phone")));
                    user.ActivationStatus = Convert.ToString(dr.GetValue(dr.GetOrdinal("us_active")));
                }
                return user;
            }
        }
    }

}

