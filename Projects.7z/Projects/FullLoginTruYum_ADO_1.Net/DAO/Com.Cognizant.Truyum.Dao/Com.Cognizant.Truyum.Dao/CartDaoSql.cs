﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Com.Cognizant.Truyum.Model;
namespace Com.Cognizant.Truyum.Dao
{
    public class CartDaoSql:ICartDao
    {
        static string callconnection = ConnectionHandler.ConnectionVariable;

        /// <summary>
        /// This method is used to add cart items into sql database-truyum
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="productId"></param>
        public void AddCartItem(long userId, long productId)
        {
            using (SqlConnection sqlConnection = new SqlConnection(callconnection))
            {
                sqlConnection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = sqlConnection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.addCartData
                };

                command.Parameters.Add(Constants.paramUserId, SqlDbType.Int).Value = userId;
                command.Parameters.Add(Constants.paramMenuId, SqlDbType.Int).Value = productId;

                command.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// This method is used to get all cart items of a particular Id
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>cart </returns>
        public Cart GetAllCartItems(long userId)
        {
            Cart cart = new Cart();
            List<MenuItem> menuList = new List<MenuItem>();
            using (SqlConnection sqlConnection = new SqlConnection(callconnection))
            {
                sqlConnection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = sqlConnection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.getAllCartItems
                };

                command.Parameters.Add(Constants.paramId, SqlDbType.Int).Value = userId;

                SqlDataReader dataReader = command.ExecuteReader();
                int count = 0;
                while (dataReader.Read())
                {
                    MenuItem menu = new MenuItem();
                    menu.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuId)));
                    menu.Name = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuName)));
                    menu.Price = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuPrice)));
                    menu.FreeDelivery = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuFreeDelivery))).
                        Equals(Constants.stringYes, StringComparison.InvariantCultureIgnoreCase) ? true : false);

                    menuList.Add(menu);
                    count++;
                }
                dataReader.Close();
                if (count == 0) //ie no items in there in cart
                {
                    throw new CartEmptyException();
                }
                cart.MenuItemList = menuList;

                SqlCommand command1 = new SqlCommand
                {
                    Connection = sqlConnection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.countTotal
                };

                command1.Parameters.Add(Constants.paramId, SqlDbType.Int).Value = userId;

                SqlDataReader dataReader1 = command1.ExecuteReader();
                while(dataReader1.Read())
                {
                    cart.Total = Convert.ToDouble(dataReader1.GetValue(dataReader1.GetOrdinal(Constants.Total)));
                }

                return cart;
            }
        }

        /// <summary>
        /// This method is used to remove the cart item list of particular id and product id
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="productId"></param>
        public void RemoveCartItem(long userId, long productId)
        {
            using (SqlConnection sqlConnection = new SqlConnection(callconnection))
            {
                sqlConnection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = sqlConnection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.deleteItem
                };

                command.Parameters.Add(Constants.paramUserId, SqlDbType.Int).Value = userId;
                command.Parameters.Add(Constants.paramMenuId, SqlDbType.Int).Value = productId;

                command.ExecuteNonQuery();
            }

        }
    }
}
