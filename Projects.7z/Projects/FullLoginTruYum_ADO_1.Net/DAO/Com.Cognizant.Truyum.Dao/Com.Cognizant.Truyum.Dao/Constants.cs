﻿namespace Com.Cognizant.Truyum.Dao
{
    public static class Constants
    {
        public static string menuId = "me_id";
        public static string menuName = "me_name";
        public static string menuPrice = "me_price";
        public static string menuActive = "me_active";
        public static string menuDateOfLaunch = "me_date_of_launch";
        public static string menuCategory = "me_category";
        public static string menuFreeDelivery = "me_free_delivery";
        public static string stringYes = "Yes";
        public static string stringNo = "No";
        public static string Total = "Total";
        public static string paramId = "@Id";
        public static string paramName = "@name";
        public static string paramPrice = "@price";
        public static string paramActive = "@active";
        public static string paramDateOfLaunch = "@dateoflaunch";
        public static string paramCategory = "@category";
        public static string paramFreeDelivery = "@freedelivery";
        public static string paramUserId = "@userid";
        public static string paramMenuId = "@menuid";

    }
}
