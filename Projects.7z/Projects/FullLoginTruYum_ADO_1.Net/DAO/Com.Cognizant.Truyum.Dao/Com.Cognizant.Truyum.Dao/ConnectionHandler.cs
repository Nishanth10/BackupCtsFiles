﻿using System.Configuration;

namespace Com.Cognizant.Truyum.Dao
{
    public class ConnectionHandler
    {
        static string _variable = ConfigurationManager.ConnectionStrings["db_connection"].ToString();
        public static string ConnectionVariable
        {
            get
            {
                return _variable;
            }
        }
    }
}
