﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Com.Cognizant.Truyum.Model;
using Com.Cognizant.Truyum.Dao;
using Com.Cognizant.Truyum.Utility;

namespace AdminUserTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestUserRegistration()
        {
            AdminUserBL ad = new AdminUserBL();
            int result = ad.UserRegistration("Sam Goes", "sam@123", 9876543210);
            //test if result is > 0 then insert success else failure
            Assert.AreEqual(1, result);
        }

       [TestMethod]
        public void TestDisplayUserByPassword()
        {
            AdminUserBL ad = new AdminUserBL();
            User u = ad.DisplaySpecificUser("sam@123");
            bool result = false;
            if(u!=null)
            {
                result = true;
            }
            Assert.AreEqual(true, result);
        }
    }
}
