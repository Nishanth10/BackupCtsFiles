﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAO;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lblMessage.Text = "";
            DisplayItems();
        }
    }

    protected void gridItem_AddButtonClick(object sender, GridViewCommandEventArgs e)
    {
        CartDaoSql cartDaoSql = new CartDaoSql();
        //find the row number for whose button you are clicking
        int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
        //through row number extract item id
        string menuItemId = gridItem.Rows[gridviewrowindex].Cells[0].Text;
        cartDaoSql.AddCartItem(1, long.Parse(menuItemId));
        lblMessage.Text = "Item added to cart successfully";
    }

    public void DisplayItems()
    {
        List<Com.Cognizant.Truyum.Model.MenuItem> menuList = MenuItemDaoSql.GetMenuItemListCustomer();
        gridItem.DataSource = menuList;
        gridItem.DataBind();
    }
}