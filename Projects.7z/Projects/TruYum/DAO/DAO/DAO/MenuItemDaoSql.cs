﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//namespace
using System.Data;
using System.Data.SqlClient;
//namespace model
using Com.Cognizant.Truyum.Model;

namespace DAO
{
    public class MenuItemDaoSql:IMenuItemDao
    {
        static string callconnection = ConnectionHandler.ConnectionVariable;
        static string getDataAdmin = "select * from menu_item;";
        static string getDataCustomer = "select * from menu_item where me_date_of_launch > GETDATE() and me_active = 'Yes';";
        static string getItemById = "select * from menu_item where me_id =@Id;";
        static string updateItem = "update menu_item set me_name=@name,me_price=@price,me_active=@active,me_date_of_launch=@dateoflaunch,me_category=@category,me_free_delivery=@freedelivery where me_id=@Id";

        public List<MenuItem> GetMenuItemListAdmin()
        {
            List<MenuItem> menuList = new List<MenuItem>();

            using (SqlConnection con = new SqlConnection(callconnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = getDataAdmin
                };

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    MenuItem menu = new MenuItem();
                    menu.Id = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("me_id")));
                    menu.Name = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_name")));
                    menu.Price = Convert.ToSingle(dr.GetValue(dr.GetOrdinal("me_price")));
                    menu.Active = (Convert.ToString(dr.GetValue(dr.GetOrdinal("me_active"))).
                        Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);
                    menu.DateOfLaunch = Convert.ToDateTime(dr.GetValue(dr.GetOrdinal("me_date_of_launch")));
                    menu.Category = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_category")));
                    menu.FreeDelivery = (Convert.ToString(dr.GetValue(dr.GetOrdinal("me_free_delivery"))).
                        Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);

                    menuList.Add(menu);
                }
                return menuList;
            }
        }

        public List<MenuItem> GetMenuItemListCustomer()
        {
            List<MenuItem> menuList = new List<MenuItem>();

            using (SqlConnection con = new SqlConnection(callconnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = getDataCustomer
                };

                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    MenuItem menu = new MenuItem();
                    menu.Id = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("me_id")));
                    menu.Name = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_name")));
                    menu.Price = Convert.ToSingle(dr.GetValue(dr.GetOrdinal("me_price")));
                    menu.Active = (Convert.ToString(dr.GetValue(dr.GetOrdinal("me_active"))).
                        Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);
                    menu.DateOfLaunch = Convert.ToDateTime(dr.GetValue(dr.GetOrdinal("me_date_of_launch")));
                    menu.Category = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_category")));
                    menu.FreeDelivery = (Convert.ToString(dr.GetValue(dr.GetOrdinal("me_free_delivery"))).
                        Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);

                    menuList.Add(menu);
                }
                return menuList;
            }
        }

        public void ModifyMenuItem(MenuItem menuItem)
        {
            using (SqlConnection con = new SqlConnection(callconnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = updateItem
                };

                cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = menuItem.Name;
                cmd.Parameters.Add("@price", SqlDbType.Decimal).Value = menuItem.Price;
                cmd.Parameters.Add("@active", SqlDbType.VarChar).Value = (menuItem.Active == true) ? "Yes" : "No";
                cmd.Parameters.Add("@dateoflaunch", SqlDbType.Date).Value = menuItem.DateOfLaunch;
                cmd.Parameters.Add("@category", SqlDbType.VarChar).Value = menuItem.Category;
                cmd.Parameters.Add("@freedelivery", SqlDbType.VarChar).Value = (menuItem.FreeDelivery == true) ? "Yes" : "No";
                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = menuItem.Id;

                cmd.ExecuteNonQuery();
            }
        }

        public MenuItem GetMenuItem(long menuItemId)
        {
            using (SqlConnection con = new SqlConnection(callconnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = getItemById
                };

                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = menuItemId;

                SqlDataReader dr = cmd.ExecuteReader();
                MenuItem menu = new MenuItem();
                while (dr.Read())
                {
                    menu.Id = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("me_id")));
                    menu.Name = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_name")));
                    menu.Price = Convert.ToSingle(dr.GetValue(dr.GetOrdinal("me_price")));
                    menu.Active = (Convert.ToString(dr.GetValue(dr.GetOrdinal("me_active"))).
                        Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);
                    menu.DateOfLaunch = Convert.ToDateTime(dr.GetValue(dr.GetOrdinal("me_date_of_launch")));
                    menu.Category = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_category")));
                    menu.FreeDelivery = (Convert.ToString(dr.GetValue(dr.GetOrdinal("me_free_delivery"))).
                        Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);

                }
                return menu;

            }
        }
    }
}
