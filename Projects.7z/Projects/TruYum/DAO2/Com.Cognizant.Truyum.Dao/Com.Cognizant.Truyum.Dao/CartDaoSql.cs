﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Com.Cognizant.Truyum.Model;
namespace Com.Cognizant.Truyum.Dao
{
    public class CartDaoSql:ICartDao
    {
        static string callconnection = ConnectionHandler.ConnectionVariable;
        public static string addCartData = "insert into cart (ct_us_id,ct_me_id) values (@userid,@menuid)";
        public static string getAllCartItems = "select * from menu_item m inner join cart c on m.me_id = c.ct_me_id where c.ct_us_id =@id;";
        public static string countTotal = "select sum(m.me_price)as Total  from menu_item m inner join cart c on m.me_id = c.ct_me_id where c.ct_us_id =@id;";
        public static string deleteItem = "Delete from cart  where ct_me_id= @menuid and ct_us_id= @userid;";

        public void AddCartItem(long userId, long productId)
        {
            using (SqlConnection con = new SqlConnection(callconnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = addCartData
                };

                cmd.Parameters.Add("@userid", SqlDbType.Int).Value = userId;
                cmd.Parameters.Add("@menuid", SqlDbType.Int).Value = productId;

                cmd.ExecuteNonQuery();
            }
        }

        public Cart GetAllCartItems(long userId)
        {
            Cart cart = new Cart();
            List<MenuItem> menuList = new List<MenuItem>();
            using (SqlConnection con = new SqlConnection(callconnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = getAllCartItems
                };

                cmd.Parameters.Add("@id", SqlDbType.Int).Value = userId;

                SqlDataReader dr = cmd.ExecuteReader();
                int count = 0;
                while (dr.Read())
                {
                    MenuItem menu = new MenuItem();
                    menu.Id = Convert.ToInt32(dr.GetValue(dr.GetOrdinal("me_id")));
                    menu.Name = Convert.ToString(dr.GetValue(dr.GetOrdinal("me_name")));
                    menu.Price = Convert.ToSingle(dr.GetValue(dr.GetOrdinal("me_price")));
                    menu.FreeDelivery = (Convert.ToString(dr.GetValue(dr.GetOrdinal("me_free_delivery"))).
                        Equals("yes", StringComparison.InvariantCultureIgnoreCase) ? true : false);

                    menuList.Add(menu);
                    count++;
                }
                dr.Close();
                if (count == 0) //ie no items in there in cart
                {
                    throw new CartEmptyException();
                }
                cart.MenuItemList = menuList;

                SqlCommand cmd1 = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = countTotal
                };

                cmd1.Parameters.Add("@id", SqlDbType.Int).Value = userId;

                SqlDataReader dr1 = cmd1.ExecuteReader();
                while(dr1.Read())
                {
                    cart.Total = Convert.ToDouble(dr1.GetValue(dr1.GetOrdinal("Total")));
                }

                return cart;
            }
        }

        public void RemoveCartItem(long userId, long productId)
        {
            using (SqlConnection con = new SqlConnection(callconnection))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = deleteItem
                };

                cmd.Parameters.Add("@userid", SqlDbType.Int).Value = userId;
                cmd.Parameters.Add("@menuid", SqlDbType.Int).Value = productId;

                cmd.ExecuteNonQuery();
            }

        }
    }
}
