USE moviecruiser;

/*1.   View Movie List Admin */

--1.a)
INSERT INTO movie VALUES
('Avengers', 356000000.00, 'Yes', '04/26/2019', 'Action', 'Yes'),
('Aladdin', 183000000.00, 'Yes', '05/24/2019', 'Adventure', 'No'),
('Captain Marvel', 175000000.00, 'Yes', '09/10/2019', 'Action', 'No'),
('The Lion King', 45000000.00, 'No', '09/17/2019', 'Animation', 'Yes'),
('First Man', 70000000.00, 'Yes', '08/29/2018', 'Adventure', 'Yes');

--1.b)
SELECT mv_title AS Title, mv_budget AS Budget, mv_active AS Active,
mv_date_of_launch AS [Date of Launch], mv_genre AS Genre , 
mv_has_teaser AS [Has Teaser] FROM movie;

/*2.   View Movie List Customer */

SELECT mv_title AS Title, mv_budget AS Budget, mv_active AS Active,
mv_date_of_launch AS [Date of Launch], mv_genre AS Genre , mv_has_teaser 
AS [Has Teaser] FROM movie WHERE 
mv_date_of_launch > GETDATE() AND mv_active='Yes' ;

/*3.   Edit Movie */

--3.a)
SELECT mv_title AS Title, mv_budget AS Budget, mv_active AS Active,
mv_date_of_launch AS [Date of Launch], mv_genre AS Genre , 
mv_has_teaser AS [Has Teaser] FROM movie where mv_id=2;

--3.b)

UPDATE movie set mv_title='Spiderman', mv_budget=295000000.00, mv_active='Yes', 
mv_date_of_launch='11/24/2019', mv_genre='Action', mv_has_teaser ='No' where mv_id=3; 

/*4.   Add to Favorite */

INSERT INTO [user] VALUES
('Admin'),
('Customer');

INSERT INTO favorite VALUES
(2,1),
(2,2),
(2,4);

/*5.   View Favorite */

SELECT mv_title AS Title, mv_active AS Active, 
mv_budget AS Budget FROM movie mv INNER JOIN favorite 
fv ON mv.mv_id = fv.fv_mv_id WHERE fv.fv_us_id=2;

SELECT SUM(mv.mv_budget) AS Total FROM movie mv INNER JOIN favorite 
fv ON mv.mv_id = fv.fv_mv_id WHERE fv.fv_us_id=2;

/*6.   Remove movie from Favorite */

DELETE FROM favorite  WHERE fv_mv_id=4 and fv_us_id=2;


