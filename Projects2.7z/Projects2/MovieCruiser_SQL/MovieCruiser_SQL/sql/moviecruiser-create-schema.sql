CREATE DATABASE moviecruiser;

USE moviecruiser;

-- User Table
CREATE TABLE [user] (
us_id bigint IDENTITY(1,1) NOT NULL,
us_name varchar(60) NULL,
CONSTRAINT PK_user PRIMARY KEY(us_id));

--movie table
CREATE TABLE movie (
mv_id bigint IDENTITY(1,1) NOT NULL,
mv_title varchar(100) NULL,
mv_budget decimal(12,2) NULL,
mv_active varchar(3) NULL,
mv_date_of_launch date NULL,
mv_genre varchar(45) NULL,
mv_has_teaser varchar(3) NULL,
CONSTRAINT PK_movie PRIMARY KEY(mv_id)); 

--favorite table
CREATE TABLE favorite (
fv_id bigint identity(1,1) NOT NULL,
fv_us_id bigint NULL,
fv_mv_id bigint NULL,
CONSTRAINT PK_favorite PRIMARY KEY(fv_id)); 

alter table favorite add constraint FK_fv_us foreign key(fv_us_id) 
references [user](us_id) on delete cascade on update cascade;

alter table favorite add constraint FK_fv_mv foreign key(fv_mv_id) 
references movie(mv_id) on delete cascade on update cascade; 
 
