﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Com.Cognizant.Truyum.Dao;
using Com.Cognizant.Truyum.Model;
using Com.Cognizant.Truyum.Utility;

namespace TruYumConsole
{
    class CartDaoCollectionTest
    {
        public CartDaoCollectionTest()
        {
            TestAddCartItem();
            TestRemoveCartItem();
        }
        public static void TestAddCartItem()
        {
            Console.WriteLine("\nAdd new item to the cart");
            CartDaoCollection cartDao = new CartDaoCollection();
            cartDao.AddCartItem(1, 1001);
            cartDao.AddCartItem(1, 1002);
            cartDao.AddCartItem(1, 1005);
            try
            {
                TestGetAllCartItems();
            }
            catch (CartEmptyException ex)
            {
                Console.WriteLine(ex);
            }
        }

        public static void TestGetAllCartItems()
        {
            CartDaoCollection cartDao = new CartDaoCollection();
            Cart cart = cartDao.GetAllCartItems(1);
            //get all info from cart for user id
            Console.WriteLine("\nName     Free Delivery     Price");
            for (int i = 0; i < cart.MenuItemList.Count; i++)
            {
                Console.WriteLine(cart.MenuItemList[i].Name + "     " +
                    cart.MenuItemList[i].FreeDelivery + "     " + cart.MenuItemList[i].Price);
            }
            Console.WriteLine("Total: " + cart.Total+"\n");
        }

        public static void TestRemoveCartItem()
        {
            Console.WriteLine("\nRemove data from cart");
            CartDaoCollection cartDao = new CartDaoCollection();
            cartDao.RemoveCartItem(1, 1001);
            try
            {
                TestGetAllCartItems();
            }
            catch (CartEmptyException ex)
            {
                Console.WriteLine(ex);
            }
        }
    }
}
