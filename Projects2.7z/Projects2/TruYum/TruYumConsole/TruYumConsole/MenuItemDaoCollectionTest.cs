﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Com.Cognizant.Truyum.Dao;
using Com.Cognizant.Truyum.Model;
using Com.Cognizant.Truyum.Utility;

namespace TruYumConsole
{
    class MenuItemDaoCollectionTest
    {
        public MenuItemDaoCollectionTest()
        {
            TestGetMenuItemListAdmin();
            TestGetMenuItemListCustomer();
            TestModifiedMenuItem();
        }
        public static void TestGetMenuItemListAdmin()
        {
            MenuItemDaoCollection menuItemDaoCollection = new MenuItemDaoCollection();
            List<MenuItem> menuList = menuItemDaoCollection.GetMenuItemListAdmin();
            Console.WriteLine("Menu display for admin");
            Console.WriteLine("{0,-10}{1,-10}{2,-10}{3,-10}{4,-10}{5,-10}{6}",
                "Id", "Name", "Price", "Active", "Date Of Launch", "Category",
                "Free Delivery");
            foreach (MenuItem menu in menuList)
            {
                Console.WriteLine(menu);
            }
        }
        public static void TestGetMenuItemListCustomer()
        {
            MenuItemDaoCollection menuItemDaoCollection = new MenuItemDaoCollection();
            List<MenuItem> menuList = menuItemDaoCollection.GetMenuItemListCustomer();
            Console.WriteLine("Menu display for Customer");
            Console.WriteLine("{0,-10}{1,-10}{2,-10}{3,-10}{4,-10}{5,-10}{6}",
                "Id", "Name", "Price", "Active", "Date Of Launch", "Category",
                "Free Delivery");
            foreach (MenuItem menu in menuList)
            {
                Console.WriteLine(menu);
            }
        }
        public static void TestModifiedMenuItem()
        {
            MenuItemDaoCollection menuItemDaoCollection = new MenuItemDaoCollection();
            MenuItem modifiedMenu = new MenuItem(1002, "Burger", 300.00f, true,
                DateUtility.convertToDate("20/12/2022"), "Starter", true);
            menuItemDaoCollection.ModifyMenuItem(modifiedMenu);

            //call the TestGetMenuItem here
            TestGetMenuItem();

        }
        public static void TestGetMenuItem()
        {
            MenuItemDaoCollection menuItemDaoCollection = new MenuItemDaoCollection();
            MenuItem menuItem = menuItemDaoCollection.GetMenuItem(1002);
            if (menuItem != null)
            {
                Console.WriteLine("\nUpdated Menu");
                Console.WriteLine("{0,-10}{1,-10}{2,-10}{3,-10}{4,-10}{5,-10}{6}",
                    "Id", "Name", "Price", "Active", "Date Of Launch", "Category",
                    "Free Delivery");
                Console.WriteLine(menuItem);
            }
            else
            {
                Console.WriteLine("No menu found to modify");
            }
        }

        
    }
}
