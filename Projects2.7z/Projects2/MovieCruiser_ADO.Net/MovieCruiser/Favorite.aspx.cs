﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.movie.dao;
using com.cognizant.movie.model;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if (!IsPostBack) {
            DisplayData();
            lblMessage.Text = "";
        }
    }
    protected void GridFavoriteDeleteButtonClick(object sender, GridViewCommandEventArgs e) {
        FavoriteDaoSqlImpl favoriteDao = new FavoriteDaoSqlImpl();
        int rowIndex = int.Parse(e.CommandArgument.ToString());
        string movieId = gridFavorite.Rows[rowIndex].Cells[0].Text;
        favoriteDao.RemoveFavorite(1, long.Parse(movieId));
        lblMessage.Text = "Movie removed from Favorites successfully";
    }

    protected void DisplayDataAfterDelete(object sender, GridViewDeleteEventArgs e) {
        DisplayData();
    }

    protected void DisplayData() {
        FavoriteDaoSqlImpl favoriteDao = new FavoriteDaoSqlImpl();
        try {
            gridFavorite.DataSource = favoriteDao.GetAllFavorites(1).MovieList;
            gridFavorite.DataBind();
            TotalBudget();
        }
        catch (FavoritesEmptyException) {
            Response.Redirect("FavoritesEmpty.aspx");
        }
    }

    protected void TotalBudget() {
        FavoriteDaoSqlImpl favoriteDao = new FavoriteDaoSqlImpl();
        Favorites favorites = favoriteDao.GetAllFavorites(1);
        lblTotalBudget.Text = favorites.Total.ToString();
    }


    protected void GridFavoriteRowDataBound(object sender, GridViewRowEventArgs e) {
        float f;
        if (float.TryParse(e.Row.Cells[3].Text, out f)) {
            e.Row.Cells[3].Text = "$" + "&nbsp;" + ((double)f).ToString();
        }
    }
}