﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace com.cognizant.movie.dao {
    public class ConnectionHandler {
        static string _variable = ConfigurationManager.ConnectionStrings["db_connection"].ToString();
        public static string GetConnection {
            get {
                return _variable;
            }
        }
    }
}
