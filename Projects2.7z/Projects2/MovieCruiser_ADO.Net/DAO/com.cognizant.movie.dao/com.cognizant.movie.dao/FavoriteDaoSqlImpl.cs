﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using com.cognizant.movie.model;

namespace com.cognizant.movie.dao {
    public class FavoriteDaoSqlImpl : IFavoritesDao {
        static string _callconnection = ConnectionHandler.GetConnection;
        public static string _addFavoriteData = "INSERT INTO favorite(fv_us_id,fv_mv_id) VALUES (@userid,@movieid)";
        public static string _getAllFavorites = "SELECT * FROM movie mv INNER JOIN favorite fv ON mv.mv_id = fv.fv_mv_id WHERE fv.fv_us_id= @Id";
        public static string _countBudget = "SELECT SUM(mv.mv_budget) AS Total FROM movie mv INNER JOIN favorite fv ON mv.mv_id = fv.fv_mv_id WHERE fv.fv_us_id=@Id";
        public static string _deleteMovie = "DELETE FROM favorite  WHERE fv_mv_id=@movieid AND fv_us_id=@userid";
        public void AddFavorite(long userId, long favoriteId) {
            using (SqlConnection sqlConnnection = new SqlConnection(_callconnection)) {
                sqlConnnection.Open();
                SqlCommand command = new SqlCommand {
                    Connection = sqlConnnection,
                    CommandType = CommandType.Text,
                    CommandText = _addFavoriteData
                };

                command.Parameters.Add("@userid", SqlDbType.Int).Value = userId;
                command.Parameters.Add("@movieid", SqlDbType.Int).Value = favoriteId;
                command.ExecuteNonQuery();
            }
        }

        public Favorites GetAllFavorites(long userId) {
            Favorites favorites = new Favorites();
            List<Movie> movieList = new List<Movie>();
            using (SqlConnection sqlConnnection = new SqlConnection(_callconnection)) {
                sqlConnnection.Open();
                SqlCommand command = new SqlCommand {
                    Connection = sqlConnnection,
                    CommandType = CommandType.Text,
                    CommandText = _getAllFavorites
                };

                command.Parameters.Add("@Id", SqlDbType.Int).Value = userId;
                SqlDataReader dataReader = command.ExecuteReader();
                int count = 0;
                while (dataReader.Read()) {
                    Movie movie = new Movie();
                    movie.Id = Convert.ToInt32
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_id")));
                    movie.Title = Convert.ToString
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_title")));
                    movie.Active = (Convert.ToString
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_active"))).
                        Equals("yes", StringComparison.InvariantCultureIgnoreCase)
                        ? true : false);
                    movie.Budget = Convert.ToSingle
                        (dataReader.GetValue(dataReader.GetOrdinal("mv_budget")));
                    movieList.Add(movie);
                    count++;
                }

                dataReader.Close();
                if (count == 0) {
                    throw new FavoritesEmptyException();
                }

                favorites.MovieList = movieList;
                SqlCommand command1 = new SqlCommand {
                    Connection = sqlConnnection,
                    CommandType = CommandType.Text,
                    CommandText = _countBudget
                };

                command1.Parameters.Add("@Id", SqlDbType.Int).Value = userId;
                SqlDataReader dataReader1 = command1.ExecuteReader();
                while (dataReader1.Read()) {
                    favorites.Total = Convert.ToDouble
                        (dataReader1.GetValue(dataReader1.GetOrdinal("Total")));
                }

                return favorites;
            }
        }

        public void RemoveFavorite(long userId, long favoriteId) {
            using (SqlConnection sqlConnnection = new SqlConnection(_callconnection)) {
                sqlConnnection.Open();
                SqlCommand command = new SqlCommand {
                    Connection = sqlConnnection,
                    CommandType = CommandType.Text,
                    CommandText = _deleteMovie
                };

                command.Parameters.Add("@userid", SqlDbType.Int).Value = userId;
                command.Parameters.Add("@movieid", SqlDbType.Int).Value = favoriteId;
                command.ExecuteNonQuery();
            }
        }
    }
}
