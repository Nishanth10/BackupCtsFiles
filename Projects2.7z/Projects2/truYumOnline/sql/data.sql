
use truyum;

/* 1.	View Menu Item List Admin  */
--1.a)
/*  menu-item table */

select * from menu_item;
insert into [dbo].[menu_item] values
('Sandwich',99.00,'Yes','03/15/2017','Main Course','Yes'),
('Burger',129.00,'Yes','12/23/2017','Main Course','No'),
('Pizza',149.00,'Yes','08/21/2018','Main Course','No'),
('French Fries',57.00,'No','07/02/2017','Starters','Yes'),
('Chocolate Brownie',32.00,'Yes','11/02/2022','Dessert','Yes');

--1.b)

select me_name as Name, me_price as Price, me_active as Active, 
me_date_of_launch as [Date of Launch], me_category as Category, 
me_free_delivery as [Free Delivery] from [dbo].[menu_item];

/*2.	View Menu Item List Customer */

select me_name as Name, me_free_delivery as [Free Delivery], 
me_price as Price, me_category as Category from [dbo].[menu_item] 
where me_date_of_launch > GETDATE() and me_active='Yes';


/*3.	Edit Menu Item */

select me_name as Name, me_price as Price, me_active as Active, 
me_date_of_launch as [Date of Launch], me_category as Category, 
me_free_delivery as [Free Delivery] from [dbo].[menu_item] where me_id=4;

update [dbo].[menu_item] set me_name='Dosa', me_price=50.00, me_active='Yes', 
me_date_of_launch='09/24/2019', me_category='Main Course', me_free_delivery='Yes' where me_id=4; 

/* 4.	Add to Cart */

insert into [dbo].[user] (us_name) values 
('Admin'),
('Customer');

insert into cart values 
(2,4),
(2,5), 
(2,2);

 /* 5.	View Cart */
 --5.a)
select me_name as Name, me_free_delivery as [Free Delivery],me_price as Price
from menu_item m inner join cart c on m.me_id = c.ct_me_id where c.ct_us_id =1;

--5.b)
select sum(m.me_price)as Total 
from menu_item m inner join cart c on m.me_id = c.ct_me_id where c.ct_us_id =2;


/*6    Remove Item from Cart */
Delete from cart  where ct_me_id=1 and ct_us_id=1;

