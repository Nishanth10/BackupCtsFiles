﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Truyum.Dao;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            DisplayItems();
        }
    }

    protected void gridItem_AddButtonClick(object sender, GridViewCommandEventArgs e)
    {
        //find the row number for whose button you are clicking
        int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
        //through row number extract item id
        string menuItemId = gridItem.Rows[gridviewrowindex].Cells[0].Text;
        Response.Redirect("AddToCart.aspx?menuItemId=" + menuItemId);
   
    }

    public void DisplayItems()
    {
        MenuItemDaoCollection menuItemDaoCollection = new MenuItemDaoCollection();
        List<Com.Cognizant.Truyum.Model.MenuItem> menuList = menuItemDaoCollection.GetMenuItemListCustomer();
        gridItem.DataSource = menuList;
        gridItem.DataBind();
    }
}