﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Cognizant.Truyum.Utility {
    public class DateUtility {
        public static DateTime convertToDate(string date) {
            DateTime dt = DateTime.ParseExact(date, "dd/MM/yyyy", null);
            return dt;
        }
    }
}
