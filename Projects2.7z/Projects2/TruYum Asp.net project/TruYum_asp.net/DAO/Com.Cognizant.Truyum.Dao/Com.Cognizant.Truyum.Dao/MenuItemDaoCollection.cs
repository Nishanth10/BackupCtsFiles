﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//refer the model under dao also
using Com.Cognizant.Truyum.Model;
using Com.Cognizant.Truyum.Utility;

namespace Com.Cognizant.Truyum.Dao
{
    public class MenuItemDaoCollection : IMenuItemDao
    {
        private static List<MenuItem> menuItemList;
        //constructor to hold a list of menu items
        public MenuItemDaoCollection()
        {
            if(menuItemList==null)
            {
                menuItemList = new List<MenuItem>();
                MenuItem menuItem1 = new MenuItem(1001, "Sandwich", 99.00f, true,
                    DateUtility.convertToDate("15/03/2017"),"Main Course", true);
                MenuItem menuItem2 = new MenuItem(1002, "Burger", 129.00f, true,
                    DateUtility.convertToDate("23/12/2017"),"Main Course", false);
                MenuItem menuItem3 = new MenuItem(1003, "Pizza", 149.00f, true,
                    DateUtility.convertToDate("21/08/2018"),"Main Course", false);
                MenuItem menuItem4 = new MenuItem(1004, "French Fries", 57.00f, false,
                    DateUtility.convertToDate("02/07/2017"),"Starters", true);
                MenuItem menuItem5 = new MenuItem(1005, "Chocolate Brownie", 32.00f, true,
                    DateUtility.convertToDate("02/11/2022"),"Dessert", true);

                //Add the menu item objects under the collection
                menuItemList.Add(menuItem1);
                menuItemList.Add(menuItem2);
                menuItemList.Add(menuItem3);
                menuItemList.Add(menuItem4);
                menuItemList.Add(menuItem5);

            }
        }
        //this is used to check if menu is modified or not
        public MenuItem GetMenuItem(long menuItemId)
        {
            MenuItem menuItem = null;
            foreach(MenuItem menu in menuItemList)
            {
                if(menu.Id==menuItemId)
                {
                    menuItem = menu;
                    break;
                }
            }
            return menuItem;
        }

        public List<MenuItem> GetMenuItemListAdmin()
        {
            return menuItemList;
        }

        public List<MenuItem> GetMenuItemListCustomer()
        {
            List<MenuItem> filteredList = new List<MenuItem>();
            foreach(MenuItem menu in menuItemList)
            {
                if(menu.DateOfLaunch>DateTime.Now && menu.Active)
                {
                    filteredList.Add(menu);
                }
                
            }
            return filteredList;
        }

        public void ModifyMenuItem(MenuItem menuItem)
        {
            for (int i=0;i<menuItemList.Count;i++)
            {
                if (menuItemList[i].Id == menuItem.Id) //ie match the record
                {
                    //present in the arg with a record present under list
                    menuItemList[i] = menuItem;
                    break;
                }
              
            }
        }
    }
}
