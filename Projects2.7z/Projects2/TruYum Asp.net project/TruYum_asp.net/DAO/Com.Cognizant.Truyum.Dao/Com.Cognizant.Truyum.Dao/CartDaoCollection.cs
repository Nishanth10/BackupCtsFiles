﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Com.Cognizant.Truyum.Model;

namespace Com.Cognizant.Truyum.Dao
{
    public class CartDaoCollection : ICartDao
    {
        private static Dictionary<long, Cart> _userCarts;
        //long is key which represents user id  and cart contains
        //value in product items

        //use constructor to pass cart information to dictionary
        public CartDaoCollection()
        {
                if(_userCarts==null)//if intially the dictionary is null
            {
                _userCarts = new Dictionary<long, Cart>();
            }
        }
        public void AddCartItem(long userId, long menuItemId)
        {
            //Get MenuItems from MenuItemCollectionDao via menuItemId
            MenuItemDaoCollection menuDao = new MenuItemDaoCollection();
            MenuItem menuItem = menuDao.GetMenuItem(menuItemId);

            //check if user id already exist in dictionary if exists add
            //new data to that user id
            if(_userCarts.ContainsKey(userId))
            {
                _userCarts[userId].MenuItemList.Add(menuItem);
            }
            else //else first create the user id and then add product to user id
            {
                Cart newCart = new Cart();
                //create a list of menu items which you want to save in your cart
                List<MenuItem> menuItems = new List<MenuItem>();
                menuItems.Add(menuItem);
                //Add the list to cart
                newCart.MenuItemList = menuItems;
                //add data to cart dictionary via id
                _userCarts.Add(userId, newCart);
            } 
        }

        public Cart GetAllCartItems(long userId)
        {
            //Create a new cart under which you will store items and total price
            Cart cart = new Cart();
            //check if user id is existing in dictionary,
            //if existing out the value from dictionary
            //TryGetValue will check under dictionary for a key; if key
            //found it will output value and result will be true; else false
            bool check = _userCarts.TryGetValue(userId, out cart);

            //check if cart is empty or ProductList is not containing any items
            if(cart==null || cart.MenuItemList.Count==0)
            {
                throw new CartEmptyException("Exception : No Item in Cart");
            }

            //check of bool result is true; if true calculate total price of items
            if(check) //is true
            {
                //extract menu informations from cart and store under
                //local list
                List<MenuItem> menuList= cart.MenuItemList;
                //Loop through all the menu present under the user id;extract
                //price of each product and do the total
                double totalPrice = 0;
                foreach(MenuItem menu in menuList)
                {
                    totalPrice += menu.Price;
                }
                cart.Total = totalPrice;
            }
            return cart;
        }

        public void RemoveCartItem(long userId, long menuItemId)
        {
            //Search data from product via itemId and remove the product
            //from the cart for the user
            //extract all items tagged to a user id and place it under local collection list
            List<MenuItem> menuList = _userCarts[userId].MenuItemList;
            //remove
            for(int i=0;i<menuList.Count;i++)
            {
                if(menuList[i].Id==menuItemId)
                {
                    menuList.RemoveAt(i); //remove Item from the found position
                }
            }

        }
    }
}
