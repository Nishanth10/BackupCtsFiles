﻿using System.Web.UI;

namespace moviecruiseronline.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}