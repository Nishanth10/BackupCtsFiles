﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.movie.model;
using com.cognizant.movie.util;
using com.cognizant.movie.dao;

namespace MovieCruiserConsole {
    class MovieDaoCollectionImplTest {
        public MovieDaoCollectionImplTest() {
            testGetMovieListAdmin();
            testGetMovieListCustomer();
            testModifyMovie();
        }

        public static void testGetMovieListAdmin() {
            MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
            List<Movie> movieList = movieDao.getMovieListAdmin();
            Console.WriteLine("Movies Display for Admin");
            Console.WriteLine("{0,-15}{1,-15}{2,-15}{3,-15}{4,-15}{5,-15}{6}",
                "Id", "Title", "Budget", "Active", "Date of Launch", "Genre",
                "Has Teaser");
            foreach (Movie movie in movieList) {
                Console.WriteLine(movie);
            }
        }

        public static void testGetMovieListCustomer() {
            MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
            List<Movie> movieList = movieDao.getMovieListCustomer();
            Console.WriteLine("\nMovies Display for Customer");
            Console.WriteLine("{0,-15}{1,-15}{2,-15}{3,-15}{4,-15}{5,-15}{6}",
                "Id", "Title", "Budget", "Active", "Date of Launch", "Genre",
                "Has Teaser");
            foreach (Movie movie in movieList) {
                Console.WriteLine(movie);
            }
        }

        public static void testModifyMovie() {
            MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
            Movie modifiedMovie = new Movie(1001, "Avengers", 756000000f, true,
                    DateUtil.convertToDate("27/11/2020"), "Sci-Fiction", true);
            movieDao.modifyMovie(modifiedMovie);

            testGetMovie();
        }

        public static void testGetMovie() {
            MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
            Movie movie = movieDao.getMovie(1001);
            if (movie != null) {
                Console.WriteLine("\nUpdated Movies");
                Console.WriteLine("{0,-15}{1,-15}{2,-15}{3,-15}{4,-15}{5,-15}{6}",
                    "Id", "Title", "Budget", "Active", "Date of Launch", "Genre",
                    "Has Teaser");
                Console.WriteLine(movie);
            }
            else {
                Console.WriteLine("No Movie found to modify");
            }
        }
    }
}
