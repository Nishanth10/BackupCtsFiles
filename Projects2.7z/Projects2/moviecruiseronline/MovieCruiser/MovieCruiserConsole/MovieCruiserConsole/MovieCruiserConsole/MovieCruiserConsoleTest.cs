﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieCruiserConsole {
    class MovieCruiserConsoleTest {
        static void Main(string[] args) {
            int movie = 0;
            Console.WriteLine("1. Movie Information\n2. Favorites Information\n3. Exit");
            do {
                movie = int.Parse(Console.ReadLine());
                switch (movie) {
                    case 1:
                        MovieDaoCollectionImplTest movieTest = new MovieDaoCollectionImplTest();
                        break;
                    case 2:
                        FavoritesDaoCollectionImplTest favoritesTest = new FavoritesDaoCollectionImplTest();
                        break;
                    case 3:
                        Environment.Exit(0);
                        break;
                }
                Console.WriteLine("\nDo you want to continue? (Press1 or 2)");
                Console.WriteLine("1. Movie Information\n2. Favorites Information\n3. Exit");
            }
            while (movie != 3);
        }
    }
}
