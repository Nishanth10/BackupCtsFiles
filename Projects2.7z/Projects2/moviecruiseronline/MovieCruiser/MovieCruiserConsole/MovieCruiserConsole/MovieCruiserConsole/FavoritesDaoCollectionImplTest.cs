﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.movie.model;
using com.cognizant.movie.util;
using com.cognizant.movie.dao;

namespace MovieCruiserConsole {
    public class FavoritesDaoCollectionImplTest {
        public FavoritesDaoCollectionImplTest() {
            testAddFavorite();
            testRemoveFavorite();
        }

        public static void testAddFavorite() {
            Console.WriteLine("\nAdd new movie to the favorite");
            FavoritesDaoCollectionImpl favoritesDao = new FavoritesDaoCollectionImpl();
            favoritesDao.addFavorite(1, 1001);
            favoritesDao.addFavorite(1, 1002);
            favoritesDao.addFavorite(1, 1004);
            try {
                testGetAllFavorites();
            }
            catch(FavoritesEmptyException ex) {
                Console.WriteLine(ex);
            }
        }

        public static void testGetAllFavorites() {
            FavoritesDaoCollectionImpl favoritesDao = new FavoritesDaoCollectionImpl();
            Favorites favorites = favoritesDao.getAllFavorites(1);
            Console.WriteLine("\n{0,-15}{1,-15}{2}","Title","Active","Budget");
            for (int i = 0; i < favorites.MovieList.Count; i++) {
                Console.WriteLine("{0,-15}{1,-15}{2}", favorites.MovieList[i].Title,
                    favorites.MovieList[i].Active, (double)favorites.MovieList[i].Budget);
            }
            Console.WriteLine("Total: " + favorites.Total + "\n");
        }

        public static void testRemoveFavorite() {
            Console.WriteLine("Remove data from favorites");
            FavoritesDaoCollectionImpl favoritesDao = new FavoritesDaoCollectionImpl();
            favoritesDao.removeFavorite(1, 1001);
            try {
                testGetAllFavorites();
            }
            catch (FavoritesEmptyException ex) {
                Console.WriteLine(ex);
            }
        }
    }
}
