﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.movie.model;

namespace com.cognizant.movie.dao {
    interface IFavoritesDao {
        void addFavorite(long userId, long favoriteId);
        Favorites getAllFavorites(long userId);
        void removeFavorite(long userId, long favoriteId);
    }
}
