﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.movie.model;

namespace com.cognizant.movie.dao {
    interface IMovieDao {
        List<Movie> getMovieListAdmin();
        List<Movie> getMovieListCustomer();
        void modifyMovie(Movie movie);
        Movie getMovie(long movieId);
    }
}
