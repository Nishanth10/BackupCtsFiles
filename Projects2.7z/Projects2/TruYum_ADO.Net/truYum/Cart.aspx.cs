﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Com.Cognizant.Truyum.Dao;
using Com.Cognizant.Truyum.Model;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            displayData();
            lblMessage.Text = "";
        }
    }

    protected void gridCart_DeleteButtonClick(object sender, GridViewCommandEventArgs e)
    {
        CartDaoSql cartDaoSql = new CartDaoSql();
        int rowIndex = int.Parse(e.CommandArgument.ToString());
        string itemId = gridCart.Rows[rowIndex].Cells[0].Text;
        cartDaoSql.RemoveCartItem(1, long.Parse(itemId));
        lblMessage.Text = "Item removed from cart successfully";
    }

    protected void Display_Data_After_Delete(object sender, GridViewDeleteEventArgs e)
    {
        displayData();
    }

    protected void displayData()
    {
        try
        {
            CartDaoSql cartDaoSql = new CartDaoSql();
            gridCart.DataSource = cartDaoSql.GetAllCartItems(1).MenuItemList;
            gridCart.DataBind();
            totalPrice();
        }
        catch (CartEmptyException)
        {
            Response.Redirect("CartEmpty.aspx");
        }
    }

    protected void totalPrice()
    {
        CartDaoSql cartDaoSql = new CartDaoSql();
        Cart cart = cartDaoSql.GetAllCartItems(1);

        lblTotalPrice.Text = cart.Total.ToString();
    }
}
