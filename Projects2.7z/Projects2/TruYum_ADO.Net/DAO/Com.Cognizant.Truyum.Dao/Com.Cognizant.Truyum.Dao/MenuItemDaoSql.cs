﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Com.Cognizant.Truyum.Model;

namespace Com.Cognizant.Truyum.Dao
{
    public class MenuItemDaoSql:IMenuItemDao
    {
        static string callconnection = ConnectionHandler.ConnectionVariable;

        /// <summary>
        /// This method is used to get Admin menu list 
        /// </summary>
        /// <returns>menuList (i.e List of Admin MenuItem from sql database-truyum)</returns>
        public List<MenuItem> GetMenuItemListAdmin()
        {
            List<MenuItem> menuList = new List<MenuItem>();

            using (SqlConnection sqlConnection = new SqlConnection(callconnection))
            {

                sqlConnection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = sqlConnection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.getDataAdmin
                };

                SqlDataReader dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    MenuItem menu = new MenuItem();
                    menu.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuId)));
                    menu.Name = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuName)));
                    menu.Price = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuPrice)));
                    menu.Active = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuActive))).
                        Equals(Constants.stringYes, StringComparison.InvariantCultureIgnoreCase) ? true : false);
                    menu.DateOfLaunch = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuDateOfLaunch)));
                    menu.Category = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuCategory)));
                    menu.FreeDelivery = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuFreeDelivery))).
                        Equals(Constants.stringYes, StringComparison.InvariantCultureIgnoreCase) ? true : false);

                    menuList.Add(menu);
                }
                return menuList;
            }
        }

        /// <summary>
        /// This method is used to get Customer menu list 
        /// </summary>
        /// <returns>menuList (i.e List of customer MenuItem from sql database-truyum)</returns>
        public List<MenuItem> GetMenuItemListCustomer()
        {
            List<MenuItem> menuList = new List<MenuItem>();

            using (SqlConnection sqlConnection = new SqlConnection(callconnection))
            {
                sqlConnection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = sqlConnection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.getDataCustomer
                };

                SqlDataReader dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    MenuItem menu = new MenuItem();
                    menu.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuId)));
                    menu.Name = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuName)));
                    menu.Price = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuPrice)));
                    menu.Active = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuActive))).
                        Equals(Constants.stringYes, StringComparison.InvariantCultureIgnoreCase) ? true : false);
                    menu.DateOfLaunch = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuDateOfLaunch)));
                    menu.Category = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuCategory)));
                    menu.FreeDelivery = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuFreeDelivery))).
                        Equals(Constants.stringYes, StringComparison.InvariantCultureIgnoreCase) ? true : false);

                    menuList.Add(menu);
                }
                return menuList;
            }
        }

        /// <summary>
        /// This method is used to modify the menu items of given id
        /// </summary>
        /// <param name="menuItem"></param>
        public void ModifyMenuItem(MenuItem menuItem)
        {
            using (SqlConnection sqlConnection = new SqlConnection(callconnection))
            {
                sqlConnection.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = sqlConnection,
                    CommandType = CommandType.Text,
                    CommandText = Queries.updateItem
                };

                command.Parameters.Add(Constants.paramName, SqlDbType.VarChar).Value = menuItem.Name;
                command.Parameters.Add(Constants.paramPrice, SqlDbType.Decimal).Value = menuItem.Price;
                command.Parameters.Add(Constants.paramActive, SqlDbType.VarChar).Value = (menuItem.Active == true) ? Constants.stringYes : Constants.stringNo;
                command.Parameters.Add(Constants.paramDateOfLaunch, SqlDbType.Date).Value = menuItem.DateOfLaunch;
                command.Parameters.Add(Constants.paramCategory, SqlDbType.VarChar).Value = menuItem.Category;
                command.Parameters.Add(Constants.paramFreeDelivery, SqlDbType.VarChar).Value = (menuItem.FreeDelivery == true) ? Constants.stringYes : Constants.stringNo;
                command.Parameters.Add(Constants.paramId, SqlDbType.Int).Value = menuItem.Id;

                command.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// This method is used to get menu item list details of particular id
        /// </summary>
        /// <param name="menuItemId"></param>
        /// <returns>menuList (i.e List of MenuItem from sql database-truyum)</returns>
        public MenuItem GetMenuItem(long menuItemId)
        {
            using (SqlConnection con = new SqlConnection(callconnection))
            {
                con.Open();
                SqlCommand command = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = Queries.getItemById
                };

                command.Parameters.Add(Constants.paramId, SqlDbType.Int).Value = menuItemId;

                SqlDataReader dataReader = command.ExecuteReader();
                MenuItem menu = new MenuItem();
                while (dataReader.Read())
                {
                    menu.Id = Convert.ToInt32(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuId)));
                    menu.Name = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuName)));
                    menu.Price = Convert.ToSingle(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuPrice)));
                    menu.Active = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuActive))).
                        Equals(Constants.stringYes, StringComparison.InvariantCultureIgnoreCase) ? true : false);
                    menu.DateOfLaunch = Convert.ToDateTime(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuDateOfLaunch)));
                    menu.Category = Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuCategory)));
                    menu.FreeDelivery = (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(Constants.menuFreeDelivery))).
                        Equals(Constants.stringYes, StringComparison.InvariantCultureIgnoreCase) ? true : false);

                }
                return menu;

            }
        }
    }
}
