﻿namespace Com.Cognizant.Truyum.Dao
{
    public static class Queries
    {
        public static string getDataAdmin = "SELECT * FROM [dbo].[menu_item](nolock)";
        public static string getDataCustomer = "SELECT * FROM [dbo].[menu_item] (nolock) WHERE me_date_of_launch > GETDATE() AND me_active = 'Yes'";
        public static string getItemById = "SELECT * FROM [dbo].[menu_item](nolock) WHERE me_id =@Id";
        public static string updateItem = "UPDATE [dbo].[menu_item] SET me_name=@name,me_price=@price,me_active=@active,me_date_of_launch=@dateoflaunch,me_category=@category,me_free_delivery=@freedelivery WHERE me_id=@Id";

        public static string addCartData = "INSERT INTO [dbo].[cart] (ct_us_id,ct_me_id) VALUES (@userid,@menuid)";
        public static string getAllCartItems = "SELECT * FROM [dbo].[menu_item](nolock) m INNER JOIN [dbo].[cart] c ON m.me_id = c.ct_me_id WHERE c.ct_us_id =@Id";
        public static string countTotal = "SELECT SUM(m.me_price) AS Total  FROM [dbo].[menu_item](nolock) m INNER JOIN cart c ON m.me_id = c.ct_me_id WHERE c.ct_us_id =@Id";
        public static string deleteItem = "DELETE FROM [dbo].[cart]  WHERE ct_me_id= @menuid AND ct_us_id= @userid";
    }
}
