﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.movie.model;

namespace com.cognizant.movie.dao {
    public class FavoritesDaoCollectionImpl : IFavoritesDao {
        private static Dictionary<long,Favorites> _userFavorites;

        public FavoritesDaoCollectionImpl() {
            if (_userFavorites == null) {
                _userFavorites = new Dictionary<long, Favorites>();
            }
        }
        public void addFavorite(long userId, long favoriteId) {
            MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
            Movie movie = movieDao.getMovie(favoriteId);
            if (_userFavorites.ContainsKey(userId)) {
                _userFavorites[userId].MovieList.Add(movie);
            }
            else {
                Favorites newfavorites = new Favorites();
                List<Movie> movieCart = new List<Movie>();
                movieCart.Add(movie);
                newfavorites.MovieList = movieCart;
                _userFavorites.Add(userId, newfavorites);
            }
        }

        public Favorites getAllFavorites(long userId) {
            Favorites favorites = new Favorites();
            bool check = _userFavorites.TryGetValue(userId, out favorites);
            if(favorites==null||favorites.MovieList.Count==0) {
                throw new FavoritesEmptyException("Exception : No movies in favorites");
            }

            if(check) {
                List<Movie> movieList = favorites.MovieList;
                double totalBudget = 0;
                foreach (Movie movie in movieList) {
                    totalBudget += movie.Budget;
                }
                favorites.Total = totalBudget;
            }
            return favorites;
        }

        public void removeFavorite(long userId, long favoriteId) {
            List<Movie> movieList = _userFavorites[userId].MovieList;
            for (int i = 0; i < movieList.Count; i++) {
                if (movieList[i].Id == favoriteId) {
                    movieList.RemoveAt(i);
                    i = -1;
                }
            }
        }
    }
}
