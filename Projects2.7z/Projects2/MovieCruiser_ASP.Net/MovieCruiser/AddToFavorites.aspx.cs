﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.movie.dao;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if (!IsPostBack) {
            lblMessage.Text = "";
            DisplayMovies();
        }
    }

    protected void GridMovieAddButtonClick(object sender, GridViewCommandEventArgs e) {
        int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
        string movieId = gridMovie.Rows[gridviewrowindex].Cells[0].Text;
        FavoritesDaoCollectionImpl favoritesDao = new FavoritesDaoCollectionImpl();
        favoritesDao.addFavorite(1, long.Parse(movieId));
        lblMessage.Text = "Movie added to Favorites Successfully";
    }

    protected void DisplayMovies() {
        MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
        List<com.cognizant.movie.model.Movie> movieList = movieDao.getMovieListCustomer();
        gridMovie.DataSource = movieList;
        gridMovie.DataBind();
    }

    protected void GridMovieRowDataBound(object sender, GridViewRowEventArgs e) {
        if (e.Row.Cells[3].Text == "True") {
            e.Row.Cells[3].Text = "Yes";
        }
        if (e.Row.Cells[3].Text == "False") {
            e.Row.Cells[3].Text = "No";
        }
        if (e.Row.Cells[6].Text == "True") {
            e.Row.Cells[6].Text = "Yes";
        }
        if (e.Row.Cells[6].Text == "False") {
            e.Row.Cells[6].Text = "No";
        }
        float f;
        if (float.TryParse(e.Row.Cells[2].Text, out f)) {
            e.Row.Cells[2].Text = "$" + "&nbsp;" + ((double)f).ToString();
        }
    }
}
