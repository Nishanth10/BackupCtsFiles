﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.movie.dao;
using com.cognizant.movie.model;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if (!IsPostBack) {
            DisplayData();
            lblMessage.Text = "";
        }
    }
    protected void GridFavoriteDeleteButtonClick(object sender, GridViewCommandEventArgs e) {
        FavoritesDaoCollectionImpl favoriteDao = new FavoritesDaoCollectionImpl();
        int rowIndex = int.Parse(e.CommandArgument.ToString());
        string movieId = gridFavorite.Rows[rowIndex].Cells[0].Text;
        favoriteDao.removeFavorite(1, long.Parse(movieId));
        lblMessage.Text = "Movie removed from Favorites successfully";
    }

    protected void DisplayDataAfterDelete(object sender, GridViewDeleteEventArgs e) {
        DisplayData();
    }

    protected void DisplayData() {
        FavoritesDaoCollectionImpl favoriteDao = new FavoritesDaoCollectionImpl();
        try {
            gridFavorite.DataSource = favoriteDao.getAllFavorites(1).MovieList;
            gridFavorite.DataBind();
            TotalBudget();
        }
        catch (FavoritesEmptyException) {
            Response.Redirect("FavoritesEmpty.aspx");
        }
    }

    protected void TotalBudget() {
        FavoritesDaoCollectionImpl favoriteDao = new FavoritesDaoCollectionImpl();
        Favorites favorites = favoriteDao.getAllFavorites(1);
        lblTotalBudget.Text = favorites.Total.ToString();
    }


    protected void GridFavoriteRowDataBound(object sender, GridViewRowEventArgs e) {
        float f;
        if (float.TryParse(e.Row.Cells[3].Text, out f)) {
            e.Row.Cells[3].Text = "$" + "&nbsp;" + ((double)f).ToString();
        }
    }
}