﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.movie.dao;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if (!IsPostBack) {
            DisplayMoviesAdmin();
        }
    }

    protected void GridMovieEditRow(object sender, GridViewEditEventArgs e) {
        GridViewRow row = gridMovie.Rows[e.NewEditIndex];     
        string movieId = row.Cells[0].Text;
        Response.Redirect("EditMovie.aspx?movieId=" + movieId);
    }

    protected void GridMovieCancelEdit(object sender, GridViewCancelEditEventArgs e) {
        gridMovie.EditIndex = -1;
    }

    protected void DisplayMoviesAdmin() {
        MovieDaoCollectionImpl movieDao = new MovieDaoCollectionImpl();
        List<com.cognizant.movie.model.Movie> movieList = movieDao.getMovieListAdmin();
        gridMovie.DataSource = movieList;
        gridMovie.DataBind();
    }

    protected void GridMovieRowDataBound(object sender, GridViewRowEventArgs e) {
     if(e.Row.Cells[3].Text=="True") {
            e.Row.Cells[3].Text = "Yes";
        }
        if (e.Row.Cells[3].Text == "False") {
            e.Row.Cells[3].Text = "No";
        }
        if (e.Row.Cells[6].Text == "True") {
            e.Row.Cells[6].Text = "Yes";
        }
        if (e.Row.Cells[6].Text == "False") {
            e.Row.Cells[6].Text = "No";
        }
        float f;
        if (float.TryParse(e.Row.Cells[2].Text, out f)) {
            e.Row.Cells[2].Text = "$" + "&nbsp;" + ((double)f).ToString();
        }
    }
}