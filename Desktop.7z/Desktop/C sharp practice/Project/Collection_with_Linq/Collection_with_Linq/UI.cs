﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Collection_with_Linq
{
    class UI
    {
        static void Main(string[] args)
        {
            List<Employee> empList = new List<Employee>();

            Employee emp = new Employee();

            string cont = string.Empty;

            int menu = 0;



        label_dataentry:

            try

            {

                do

                {

                    Console.WriteLine("Enter name and id:");

                    string[] data = Console.ReadLine().Split(',');

                    if (Regex.IsMatch(data[1], "^[0-9]{4}$"))

                    {

                        //put data under employee constructor and pass the

                        //employee constructor under Add() of List

                        empList.Add(new Employee(data[0], int.Parse(data[1])));

                    }

                    else

                    {

                        throw new EmployeeBO("Id not correct");

                    }

                    Console.WriteLine("Enter another employee?(yes/no):");

                    cont = Console.ReadLine();

                }

                while (cont.Equals("yes",

                StringComparison.InvariantCultureIgnoreCase));

            }

            catch (EmployeeBO ebo)

            {

                Console.WriteLine("Exception: " + ebo);

                Console.WriteLine("Enter the details again:");

                goto label_dataentry;

            }



            Console.WriteLine();

            //Display data

            do

            {

                Console.WriteLine("\nMenu\n1.All Employee\n2.Filtered by Id\n3.Exit");

                menu = int.Parse(Console.ReadLine());

                switch (menu)

                {

                    case 1:

                        EmployeeBO.Display(empList);

                        break;



                    case 2:

                        Console.WriteLine("Enter id to search:");

                        int search = int.Parse(Console.ReadLine());

                        Employee empp = EmployeeBO.Display(empList, search);

                        if (empp != null)

                            Console.WriteLine(empp);

                        else

                            Console.WriteLine("No record found");

                        break;



                    case 3:

                        //terminate C# program

                        Environment.Exit(0);

                        break;

                }

            }

            while (menu != 3);
        }
    }
}
