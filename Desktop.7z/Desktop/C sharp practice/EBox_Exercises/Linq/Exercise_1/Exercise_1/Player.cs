﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_1
{
    class Player
    {
        private string _playerName;
        private long _runs;

        public Player()
        {
                
        
        }

        public Player(string _playerName, long _runs)
        {
            this.PlayerName = _playerName;
            this.Runs = _runs;
        }

        public string PlayerName
        {
            get
            {
                return _playerName;
            }

            set
            {
                _playerName = value;
            }
        }

        public long Runs
        {
            get
            {
                return _runs;
            }

            set
            {
                _runs = value;
            }
        }
        public override string ToString()
        {
            return string.Format("{0,-10}{1}", this._playerName, this._runs);
        }


    }
}
