﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_1
{
    class Program
    {
        public static List<Player> Display(List<Player> plyList)
        {
            List<Player> plyr = new List<Player>();
            var check_data = from d in plyList
                             where d.Runs > 50
                             select d;
            if (check_data.Count() > 0)
            {
                foreach (Player ply1 in check_data)
                {
                    plyr.Add(ply1);

                }
            }
            return plyr;
        }

        static void Main(string[] args)
        {
            List<Player> plyList = new List<Player>();

            Console.WriteLine("Enter the number of players");
            int size = int.Parse(Console.ReadLine());
            for (int i = 0; i < size; i++)
            {
                Console.WriteLine("Enter player name");
                string _name = Console.ReadLine();
                Console.WriteLine("Enter score");
                int _runs = int.Parse(Console.ReadLine());
                plyList.Add(new Player(_name, _runs));
            }

            List<Player> plyr = Display(plyList);

            if (plyr.Capacity != 0)
            {
                foreach (var p in plyr)
                {
                    Console.WriteLine(p);
                }
            }

            else
                Console.WriteLine("No record found");
        }

    }
}

