﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_2
{
    class Utility:Exception
    {
        private string _msg;

        public Utility(string _msg)
        {
            this._msg = _msg;
        }

        public Utility()
        {

        }
        public static string GetLOBAcctCount(string _lobName, int _count)
        {

            return string.Format("The LOB " + _lobName + " has " + _count + " accounts");
        }

        public override string ToString()
        {
            return string.Format("{0}", this._msg);
        }

    }
}
