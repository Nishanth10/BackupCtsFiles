﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_2
{
    class Program
    {
        static void Main(string[] args)
        {
           
            try
            {

                Console.WriteLine("Please enter the Line of Business (LOB)name:");
                string _lobName = Console.ReadLine();
                Console.WriteLine("Please enter the account count for the LOB:");

                char[] _data = Console.ReadLine().ToCharArray();
                int n = 0;
                foreach (char k in _data)
                {
                    if (char.IsDigit(k))
                    {
                        n++;
                    }
                }
                int _count = 0;
                if (n == _data.Length)
                {
                    _count = int.Parse(new string(_data));
                    Console.WriteLine(Utility.GetLOBAcctCount(_lobName, _count));
                }
                else
                {
                    throw new Utility("Incorrect value provided for Account count. Please check.");
                }


            }

            catch (Utility e)
            {
                {
                    Console.WriteLine("Exception caught at Main method: " + e);
                }
            }
        }
    }
}

