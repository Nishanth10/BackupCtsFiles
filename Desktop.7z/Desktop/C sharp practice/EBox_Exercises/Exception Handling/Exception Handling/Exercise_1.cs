﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception_Handling
{
    class Exercise_1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter the Line of Business (LOB) name:");
            string lobName = Console.ReadLine();
            Console.WriteLine("Please enter the account count for the LOB:");
            int accountCount;

            try
            {
                accountCount = int.Parse(Console.ReadLine());
                Console.WriteLine("The LOB BFS has " + accountCount + " accounts");
            }
            catch (FormatException ex)
            {
               Console.WriteLine("Incorrect value provided for Account count. Please check.");
            }
        }
    }
}
