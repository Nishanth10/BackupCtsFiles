﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_3
{
    class Custom:Exception
    {
        private string _msg;

        public Custom(string _msg)
        {
            this._msg = _msg;
        }

        public Custom()
        {

        }
        public static int GetNumber(int _num1, int _num2)
        {

            return _num1 + _num2;
        }

        public override string ToString()
        {
            return string.Format("{0}", this._msg);
        }


    }
}
