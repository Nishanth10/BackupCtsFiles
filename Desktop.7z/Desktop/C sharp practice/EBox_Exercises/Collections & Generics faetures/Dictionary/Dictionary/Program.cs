﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionary
{
    class Program
    {
        static void Main(string[] args)
        {

            SortedDictionary<int, string> students = new SortedDictionary<int, string>();

            students.Add(1, "Alok");
            students.Add(2, "Nadeem");
            students.Add(3, "Udit");

            Console.WriteLine("List of Students in the department");
            foreach (var student in students)

            {

                Console.WriteLine("ID: " + student.Key + " Name: " + student.Value);

            }

        }
    }
}
