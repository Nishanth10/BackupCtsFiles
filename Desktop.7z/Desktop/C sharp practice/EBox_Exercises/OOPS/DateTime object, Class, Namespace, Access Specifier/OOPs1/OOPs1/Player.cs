﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPs1
{
    class Player
    {
        private string _name;
        private string _skill;
        private string _country;

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public string Skill
        {
            get
            {
                return _skill;
            }

            set
            {
                _skill = value;
            }
        }

        public string Country
        {
            get
            {
                return _country;
            }

            set
            {
                _country = value;
            }
        }
    }
}
