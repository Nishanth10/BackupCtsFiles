﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_1
{
    class Delivery
    {
        public void DisplayDeliveryDetails(String bowler, String batsman)
        {
            string[] bowlerlastname = bowler.Split(' ');
            string[] batsmanlastname = batsman.Split(' ');

            Console.WriteLine("Bowler-" + bowlerlastname[bowlerlastname.Length - 1] + "\nBatsman-" + batsmanlastname[batsmanlastname.Length - 1]);

        }


        public void DisplayDeliveryDetails(long runs)
        {
            if (runs < 4)
            {
                Console.WriteLine("Number of runs scored in the delivery : " + runs);
            }
            else
            {
                if (runs == 4)
                {
                    Console.WriteLine("Number of runs scored in the delivery : " + runs + "\nIt is a boundary");
                }
                if (runs == 6)
                {
                    Console.WriteLine("Number of runs scored in the delivery : " + runs + "\nIt is a Six");
                }
            }
        }

    }
}
