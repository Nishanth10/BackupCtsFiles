﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_2
{
    class HockeyPlayer : Player, IPlayerStatistics
    {
        private string _position;
        private int _noOfGoals;



        public string Position
        {
            get
            {
                return _position;
            }

            set
            {
                _position = value;
            }
        }

        public int NoOfGoals
        {
            get
            {
                return _noOfGoals;
            }

            set
            {
                _noOfGoals = value;
            }
        }
        public HockeyPlayer()
        {

        }
        public HockeyPlayer(string _position, int _noOfGoals, string _name, string _teamName, int _noOfMatches) : base(_name, _teamName, _noOfMatches)
        {
            this.Position = _position;
            this.NoOfGoals = _noOfGoals;
        }



        public void DisplayPlayerStatistics()
        {
            Console.WriteLine("Player Details");
            Console.WriteLine("Player name: {0} \nTeam name: {1}\nNo of matches: {2}\nPosition: {3}\nNo of goals taken: {4}", base.Name, base.TeamName, base.NoOfMatches, this._position, this._noOfGoals);
        }
    }


}