﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delivery_Details
{
    class Delivery
    {

        private long _over;
        private long _ball;
        private long _runs;
        private string _batsman;
        private string _bowler;
        private string _nonStriker;

        public Delivery(long _over, long _ball, long _runs, string _batsman, string _bowler, string _nonStriker)
        {
            this._over = _over;
            this._ball = _ball;
            this._runs = _runs;
            this._batsman = _batsman;
            this._bowler = _bowler;
            this._nonStriker = _nonStriker;
        }

        public override string ToString()
        {
            return string.Format("Over : {0}\nBall : {1}\nRuns : {2}\nBatsman: {3}\nBowler : {4}\nNonStriker : {5}", this._over, this._ball, this._runs, this._batsman, this._bowler, this._nonStriker);

        }
    }
}
