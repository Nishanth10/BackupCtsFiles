﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Exercise_2
    {
        static void Main(string[] args)
        {
            float fahrenheit= float.Parse(Console.ReadLine());
            float centigrade = (fahrenheit - 32) * 5 / 9;
            Console.WriteLine(centigrade.ToString("0.00"));
        }
    }
}
