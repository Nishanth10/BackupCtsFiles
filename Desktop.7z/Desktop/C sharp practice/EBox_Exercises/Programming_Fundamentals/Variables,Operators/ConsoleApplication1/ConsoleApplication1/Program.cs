﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Exercise_1
    {
        public static int addition(int a, int b)
        {
            int sum = a + b;
            return sum;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter the first number");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Please enter the second number");
            int num2 = int.Parse(Console.ReadLine());
            Console.WriteLine("The sum of the 2 numbers is "+ addition(num1,num2));
        }
    }
}
