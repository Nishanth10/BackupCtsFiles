﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_1
{
    class Team_Selection
    {
        static void Main(string[] args)
        {
            int size = int.Parse(Console.ReadLine());
            if (size < 0)
            {
                Console.WriteLine("Invalid Input");
            }
            else
            {
                string[] teams = new string[size];
                for (int i = 0; i < size; i++)
                {
                    teams[i] = Console.ReadLine();
                }

                string check = Console.ReadLine();
                if (teams.Contains(check))
                {
                    Console.WriteLine("Yes");
                    Console.WriteLine(Array.IndexOf(teams, check) + 1);
                }
                else
                {
                    Console.WriteLine("No");
                }
            }

        }
    }
}
