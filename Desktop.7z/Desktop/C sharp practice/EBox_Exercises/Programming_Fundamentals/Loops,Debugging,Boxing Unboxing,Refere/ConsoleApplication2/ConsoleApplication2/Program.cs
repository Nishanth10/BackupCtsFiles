﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Exercise_1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your date of joining in ‘mm/dd/yyyy’ format in your current organization.");
            DateTime doj = DateTime.ParseExact(
            Console.ReadLine(), "MM/dd/yyyy", null);
            DateTime current = DateTime.Now;
            TimeSpan ts = current.Subtract(doj);

            int duration = (int)ts.TotalDays;
            Console.WriteLine("It has been " + duration + " days since you joined the current organization.");
        }
    }
}
