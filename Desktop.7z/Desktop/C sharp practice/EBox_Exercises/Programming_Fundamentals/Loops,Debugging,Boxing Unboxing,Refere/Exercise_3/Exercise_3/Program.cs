﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[3];
            int count = 0;
            Console.WriteLine("Current constituency vote count details in ‘Constituency number – vote count’ format: ");
            for (int i = 0; i < 3; i++)
            {
                count++;
                Console.Write(count + "-");
                arr[i] = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("Please provide the constituency number for which the vote count should be modified: ");
            int pos = int.Parse(Console.ReadLine());

            Console.WriteLine("Please provide the new vote count: ");
            int val = int.Parse(Console.ReadLine());

            Console.WriteLine("Current constituency vote count details in ‘Constituency number – vote count’ format: ");
            for (int i = 0; i < 3; i++)
            {
                if (i == pos - 1)
                {
                    arr[i] = val;
                }
            }

            count = 0;
            for (int i = 0; i < 3; i++)
            {
                count++;
                Console.Write(count + "-");
                Console.WriteLine(arr[i]);
            }

        }
    }
}
