﻿using System;

namespace SampleOutput1
{
    class Example
    {
        static void Main(string[] args)
        {
            //CTRL+F5 to exec

            int id = 1001;
            string name = "Sam";
            char gender = 'M';
            float fees = 1000.23F;
            double salary = 90000.55;

            //Console.WriteLine("Id: " + id+"\nName: "+name);

            Console.WriteLine("Id: {0}\nName: {1}\nGender: {2}" +
            "\nFees: {3}\nSalary: {4}", id, name, gender, fees, salary);
        }
    }
}
