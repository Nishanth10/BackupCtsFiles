﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Variable_Example
{
    class Example_Variable
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter id:");

            int id = int.Parse(Console.ReadLine());



            Console.WriteLine("Enter Name:");

            string name = Console.ReadLine();



            Console.WriteLine("Enter fees:");

            float fees = float.Parse(Console.ReadLine());



            Console.WriteLine("Name: {0}\nId: {1}\nFees: {2}",

           name, id, fees);
        }
    }
}
