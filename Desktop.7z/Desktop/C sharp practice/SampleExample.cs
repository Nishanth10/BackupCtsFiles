//Namespace
using System;
class SampleExample
{
static void Main()
{
Console.WriteLine("Hello World");
}
}