﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_1
{
    enum Lines_of_Business
    {
       BFS,
       Healthcare,
       Insurance
    }
    class Program
    {
        static void Main(string[] args)
        {
            //create a filestream for writing purpose

            FileStream fs = new FileStream(@"D:/LinesOfBusiness.txt",

            FileMode.OpenOrCreate, FileAccess.Write);



            StreamWriter writter = new StreamWriter(fs);



            //Print names of placeholder present under enum

            foreach (string d in Enum.GetNames(typeof(Lines_of_Business)))

            {
               // System.Threading.Thread.Sleep(2000);

                writter.WriteLine(d);

                writter.Flush();

            }

           // Console.WriteLine("File Writing completed");

            writter.Close();

            fs.Close();



            //create a filestream for reading purpose

            FileStream fs1 = new FileStream(@"D:/LinesOfBusiness.txt",

           FileMode.OpenOrCreate, FileAccess.Read);



            StreamReader reader = new StreamReader(fs1);

            reader.BaseStream.Seek(0, SeekOrigin.Begin);



            string storage = string.Empty;



            while ((storage = reader.ReadLine()) != null)

            //read data till EOF

            {

               // System.Threading.Thread.Sleep(2000);

                Console.WriteLine(storage);

            }

           // Console.WriteLine("\nData Reading completed");

            reader.Close();

            fs1.Close();
        }
    }
}
