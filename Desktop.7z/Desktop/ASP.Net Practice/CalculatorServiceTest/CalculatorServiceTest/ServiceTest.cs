﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CalculatorServiceTest
{
    [TestClass]
    public class ServiceTest
    {
        [TestMethod]
        public void additionCondition1()
        {
            //both data are +ve
            int result_expected = 10;
          
            //Create a Service class object
            CalculatorServiceCall.CalculatorWebServiceSoapClient client = 
                new CalculatorServiceCall.CalculatorWebServiceSoapClient();

            //through the client call the web service class methods
            //of the class
            int actual_result = client.Addition(2, 8);
            //Check whether testcase is passing
            Assert.AreEqual(result_expected, actual_result);
        

        }

        [TestMethod]
        public void additionCondition2()
        {
            //a is -ve, b is +ve
            int result_expected = 10;

            //Create a Service class object
            CalculatorServiceCall.CalculatorWebServiceSoapClient client =
                new CalculatorServiceCall.CalculatorWebServiceSoapClient();

            //through the client call the web service class methods
            //of the class
            int actual_result = client.Addition(-2, 8);
            //Check whether testcase is passing
            Assert.AreEqual(result_expected, actual_result);
        }

        [TestMethod]
        public void additionCondition3()
        {
            //b is -ve, a is +ve
            int result_expected = 10;

            //Create a Service class object
            CalculatorServiceCall.CalculatorWebServiceSoapClient client =
                new CalculatorServiceCall.CalculatorWebServiceSoapClient();

            //through the client call the web service class methods
            //of the class
            int actual_result = client.Addition(2, -8);
            //Check whether testcase is passing
            Assert.AreEqual(result_expected, actual_result);

        }

        [TestMethod]
        public void subtractionCondition1()
        {
            //a and b both +ve and a>b
            int result_expected = 8;

            //Create a Service class object
            CalculatorServiceCall.CalculatorWebServiceSoapClient client =
                new CalculatorServiceCall.CalculatorWebServiceSoapClient();

            //through the client call the web service class methods
            //of the class
            int actual_result = client.Subtract(10, 2);
            //Check whether testcase is passing
            Assert.AreEqual(result_expected, actual_result);
        }

        [TestMethod]
        public void subtractionCondition2()
        {
            //a and b both +ve and b>a
            int result_expected = 8;

            //Create a Service class object
            CalculatorServiceCall.CalculatorWebServiceSoapClient client =
                new CalculatorServiceCall.CalculatorWebServiceSoapClient();

            //through the client call the web service class methods
            //of the class
            int actual_result = client.Subtract(2, 10);
            //Check whether testcase is passing
            Assert.AreEqual(result_expected, actual_result);
        }

        [TestMethod]
        public void subtractionCondition3()
        {
            //a is -ve, b is +ve
            int result_expected = 8;

            //Create a Service class object
            CalculatorServiceCall.CalculatorWebServiceSoapClient client =
                new CalculatorServiceCall.CalculatorWebServiceSoapClient();

            //through the client call the web service class methods
            //of the class
            int actual_result = client.Subtract(-10, 2);
            //Check whether testcase is passing
            Assert.AreEqual(result_expected, actual_result);
        }

        [TestMethod]
        public void subtractionCondition4()
        {
            //a is +ve, b is -ve
            int result_expected = 8;

            //Create a Service class object
            CalculatorServiceCall.CalculatorWebServiceSoapClient client =
                new CalculatorServiceCall.CalculatorWebServiceSoapClient();

            //through the client call the web service class methods
            //of the class
            int actual_result = client.Subtract(10, -2);
            //Check whether testcase is passing
            Assert.AreEqual(result_expected, actual_result);
        }
    }
}
