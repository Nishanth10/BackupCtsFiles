﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Auto execution of code when page is loaded in browser
        textDisplay.Text = "Welcome User";

    }

    protected void btnNext_Click(object sender, EventArgs e)
    {
        textDisplay.Text = "Hello Trainees";
    }

    protected void btnStaticButton_Click(object sender, EventArgs e)
    {
        Response.Write("Today date: " +
            DateTime.Now.ToString("dd/MM/yyyy"));
    }

    protected void btnPopUpButton_Click(object sender, EventArgs e)
    {
        string current_time = DateTime.Now.ToString("hh:mm:ss");
        Response.Write("<script>alert('Current Time: " + current_time + "')</script>");
    }

    protected void btnRedirect_Click(object sender, EventArgs e)
    {
        Response.Redirect("login.aspx");
    }

    protected void btnTransfer_Click(object sender, EventArgs e)
    {
        Server.Transfer("Login.aspx");
    }

    protected void btnMessage_Redirect_Click(object sender, EventArgs e)
    {
        string userMessage = "Welcome User";
        Response.Write("<script>alert('Message: " + userMessage + "');" +
            "window.location.href='Login.aspx';</script>");
    }
}