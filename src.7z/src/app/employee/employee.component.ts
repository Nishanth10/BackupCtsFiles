import { Component, OnInit } from '@angular/core';
import { Employee } from './employee';



@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  public submitted = false;
  public model: any;
  constructor() { }

  ngOnInit() {
    this.model = new Employee(null, 0, null);
  }
  onSubmit() {
    this.submitted = true;
  }
  newEmployee() {

  }


}




