export class Employee {
    constructor(public name: string, public id: number, public phone: string) {

    }
} 
