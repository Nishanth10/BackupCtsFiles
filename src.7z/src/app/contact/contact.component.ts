import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  public employeeForm: FormGroup;
  public submitted = false;
  constructor() { }

  ngOnInit() {
    this.employeeForm = new FormGroup({ name: new FormControl('', Validators.required), id: new FormControl('', Validators.required), phone: new FormControl('', Validators.required) });
  }

  onSubmit() {

    if (this.employeeForm.valid) {
      this.submitted = true;
      console.log(this.employeeForm.value);
    }
    else {
      alert("Form Invalid");

    }
  }

  onReset() {
    this.employeeForm.reset();
  }

}
