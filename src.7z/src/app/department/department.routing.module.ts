import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DepartmentListComponent } from './department-list/department-list.component';
import { NewDepartmentComponent } from './new-department/new-department.component';
import { DepartmentComponent } from './department.component';


const routes: Routes = [
    {
        path: '', component: DepartmentComponent,
        children:
            [
                { path: '', component: DepartmentListComponent },
                { path: 'new-department', component: NewDepartmentComponent}

            ]
    }
]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],

})
export class DepartmenRoutingModule { }
