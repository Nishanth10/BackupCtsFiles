import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-department',
  templateUrl: './new-department.component.html',
  styleUrls: ['./new-department.component.css']
})
export class NewDepartmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
