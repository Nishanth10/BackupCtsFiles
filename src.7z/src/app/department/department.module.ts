import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DepartmentComponent } from './department.component';
import { NewDepartmentComponent } from './new-department/new-department.component';
import { DepartmentListComponent } from './department-list/department-list.component';
import { DepartmenRoutingModule } from './department.routing.module';


@NgModule({
  declarations: [
      DepartmentComponent,
      DepartmentListComponent,
      NewDepartmentComponent

  ],
  imports: [
      DepartmenRoutingModule

  ],
  providers: [],
})
export class DepartmentModule { }
